from __future__ import annotations

import unittest

from dm_odoo_test.cli import process_sample_mention
from dm_odoo_test.odoo_client import (
    SampleLead,
    SampleLeadResolver,
    parse_sample_request_body,
    swap_postcode_city_if_inverted,
)
from dm_odoo_test.sample_parser import SampleMention, extract_sample_mentions


class FakeResolver:
    def __init__(self, lead: SampleLead) -> None:
        self.lead = lead
        self.moved_to_stage: tuple[int, str] | None = None

    def resolve(self, candidates: list[str]) -> SampleLead:
        return self.lead

    def move_to_stage(self, lead_id: int, stage_name: str) -> dict:
        self.moved_to_stage = (lead_id, stage_name)
        return {"ok": True, "stage_id": 12, "stage_name": stage_name}


class FakeDeliveryMatchClient:
    def __init__(self, duplicate_response: dict | None = None) -> None:
        self.duplicate_response = duplicate_response or {
            "ok": False,
            "status_code": 404,
            "json": {"message": "not found"},
        }
        self.insert_called = False

    def get_shipment_by_order_number(self, order_number: str) -> dict:
        return self.duplicate_response

    def insert_shipment(self, payload: dict) -> dict:
        self.insert_called = True
        return {"ok": True, "status_code": 200, "json": {"shipmentID": 123, "shipment": {"orderNumber": payload["shipment"]["orderNumber"]}}}


class SampleFlowTests(unittest.TestCase):
    def test_extracts_multiple_sample_requests_from_one_github_input_line(self) -> None:
        text = (
            "Re: Sample Aanvraag - Iris Siemerink "
            "Re: Sample Aanvraag - Lotte Spek "
            "Re: sample Aanvraag - Stefanie de Groot"
        )

        names = [mention.best_name for mention in extract_sample_mentions(text)]

        self.assertEqual(names, ["Iris Siemerink", "Lotte Spek", "Stefanie de Groot"])

    def test_extracts_sales_opportunity_name_from_flat_github_input_line(self) -> None:
        text = (
            "Re: Sample Aanvraag - Carl Cocy "
            "Leonie Wothuis Verkoopfans "
            "Re: Sample Aanvraag - Linda van t Hooft"
        )

        mentions = extract_sample_mentions(text)
        names = [mention.best_name for mention in mentions]

        self.assertEqual(names, ["Carl Cocy", "Leonie Wothuis", "Linda van t Hooft"])
        self.assertIn("Linda van t Hooft", mentions[-1].candidates)

    def test_live_write_skips_existing_deliverymatch_shipment(self) -> None:
        lead = SampleLead(
            id=71318,
            sample_name="Iris Siemerink",
            lead_name="Re: Sample Aanvraag - Iris Siemerink",
            receiver={
                "name": "Iris Siemerink",
                "street": "Kerkstraat",
                "house_number": "12",
                "postcode": "1234AB",
                "city": "Enter",
                "country": "NL",
            },
            stage_name="Te versturen/binnen",
        )
        dm_client = FakeDeliveryMatchClient(
            {"ok": True, "status_code": 200, "json": {"shipment": {"id": 456, "orderNumber": "SAMPLE-71318"}}}
        )

        resolver = FakeResolver(lead)
        result = process_sample_mention(
            SampleMention(raw_text="Iris Siemerink", candidates=["Iris Siemerink"]),
            resolver=resolver,
            dm_client=dm_client,
            dm_client_id="101276",
            pickup_date=None,
            reference="sample",
            execute_write=True,
            force=False,
            duplicate_log={},
            print_payload=False,
            processed_stage_name="Verzonden/meegegeven",
        )

        self.assertEqual(result["status"], "skipped_duplicate")
        self.assertFalse(dm_client.insert_called)
        self.assertEqual(result["deliverymatch_existing"]["shipmentID"], 456)
        self.assertEqual(resolver.moved_to_stage, (71318, "Verzonden/meegegeven"))
        self.assertEqual(result["odoo_stage_update"]["stage_name"], "Verzonden/meegegeven")

    def test_missing_address_reports_matched_odoo_lead(self) -> None:
        lead = SampleLead(
            id=71318,
            sample_name="Iris Siemerink",
            lead_name="Re: Sample Aanvraag - Iris Siemerink",
            receiver={"name": "Iris Siemerink", "postcode": "1234AB", "city": "Enter", "country": "NL"},
        )

        result = process_sample_mention(
            SampleMention(raw_text="Iris Siemerink", candidates=["Iris Siemerink"]),
            resolver=FakeResolver(lead),
            dm_client=None,
            dm_client_id="101276",
            pickup_date=None,
            reference="sample",
            execute_write=False,
            force=False,
            duplicate_log={},
            print_payload=False,
            processed_stage_name="Verzonden/meegegeven",
        )

        self.assertEqual(result["status"], "error")
        self.assertEqual(result["odoo_lead_id"], 71318)
        self.assertIn("Adresregel ontbreekt", result["error"])

    def test_dry_run_reports_duplicate_check_skipped_without_api_client(self) -> None:
        lead = SampleLead(
            id=71318,
            sample_name="Iris Siemerink",
            lead_name="Re: Sample Aanvraag - Iris Siemerink",
            receiver={
                "name": "Iris Siemerink",
                "street": "Kerkstraat",
                "house_number": "12",
                "postcode": "1234AB",
                "city": "Enter",
                "country": "NL",
            },
        )

        result = process_sample_mention(
            SampleMention(raw_text="Iris Siemerink", candidates=["Iris Siemerink"]),
            resolver=FakeResolver(lead),
            dm_client=None,
            dm_client_id="101276",
            pickup_date=None,
            reference="sample",
            execute_write=False,
            force=False,
            duplicate_log={},
            print_payload=False,
            processed_stage_name="Verzonden/meegegeven",
        )

        self.assertEqual(result["status"], "dry-run")
        self.assertEqual(result["duplicate_check"], "not_run_no_deliverymatch_api_key")

    def test_force_creates_new_shipment_even_when_deliverymatch_has_duplicate(self) -> None:
        lead = SampleLead(
            id=71318,
            sample_name="Iris Siemerink",
            lead_name="Re: Sample Aanvraag - Iris Siemerink",
            receiver={
                "name": "Iris Siemerink",
                "street": "Kerkstraat",
                "house_number": "12",
                "postcode": "1234AB",
                "city": "Enter",
                "country": "NL",
            },
            stage_name="Te versturen/binnen",
        )
        dm_client = FakeDeliveryMatchClient(
            {"ok": True, "status_code": 200, "json": {"shipment": {"id": 456, "orderNumber": "SAMPLE-71318"}}}
        )
        resolver = FakeResolver(lead)

        result = process_sample_mention(
            SampleMention(raw_text="Iris Siemerink", candidates=["Iris Siemerink"]),
            resolver=resolver,
            dm_client=dm_client,
            dm_client_id="101276",
            pickup_date=None,
            reference="sample",
            execute_write=True,
            force=True,
            duplicate_log={"71318": {"ok": True, "shipmentID": 456}},
            print_payload=False,
            processed_stage_name="Verzonden/meegegeven",
        )

        self.assertEqual(result["status"], "sent")
        self.assertTrue(dm_client.insert_called)
        self.assertEqual(result["duplicate_check"], "skipped_force")
        self.assertEqual(result["orderNumber"], "SAMPLE-71318")
        self.assertEqual(resolver.moved_to_stage, (71318, "Verzonden/meegegeven"))

    def test_bypass_all_checks_creates_shipment_for_closed_stage_with_retry_suffix(self) -> None:
        class RetryDeliveryMatchClient:
            def __init__(self) -> None:
                self.insert_payloads: list[dict] = []
                self.duplicate_response = {
                    "ok": False,
                    "status_code": 409,
                    "json": {"message": "Shipment with this order number already exists", "shipmentID": 28028912},
                }

            def get_shipment_by_order_number(self, order_number: str) -> dict:
                return self.duplicate_response

            def insert_shipment(self, payload: dict) -> dict:
                self.insert_payloads.append({"orderNumber": payload["shipment"]["orderNumber"]})
                if len(self.insert_payloads) == 1:
                    return self.duplicate_response
                return {
                    "ok": True,
                    "status_code": 200,
                    "json": {
                        "shipmentID": 999,
                        "shipment": {"orderNumber": payload["shipment"]["orderNumber"]},
                    },
                }

        lead = SampleLead(
            id=7087,
            sample_name="Mendy Kogelman",
            lead_name="Re: Sample Aanvraag - Mendy Kogelman",
            receiver={
                "name": "Mendy Kogelman",
                "street": "Kruisbergseweg",
                "house_number": "144",
                "postcode": "7009BT",
                "city": "Doetinchem",
                "country": "NL",
            },
            stage_name="Verzonden/meegegeven",
        )
        resolver = FakeResolver(lead)
        dm_client = RetryDeliveryMatchClient()

        result = process_sample_mention(
            SampleMention(raw_text="Mendy Kogelman", candidates=["Mendy Kogelman"]),
            resolver=resolver,
            dm_client=dm_client,
            dm_client_id="101276",
            pickup_date=None,
            reference="sample",
            execute_write=True,
            force=True,
            bypass_all_checks=True,
            duplicate_log={},
            print_payload=False,
            processed_stage_name="Verzonden/meegegeven",
        )

        self.assertEqual(result["status"], "sent")
        self.assertEqual(len(dm_client.insert_payloads), 2)
        self.assertEqual(dm_client.insert_payloads[0]["orderNumber"], "SAMPLE-7087")
        self.assertTrue(dm_client.insert_payloads[1]["orderNumber"].startswith("SAMPLE-7087-RETRY-"))
        self.assertTrue(result.get("bypass_retry_with_suffix"))

    def test_live_write_skips_lead_when_stage_is_not_te_versturen_binnen(self) -> None:
        lead = SampleLead(
            id=71318,
            sample_name="Iris Siemerink",
            lead_name="Re: Sample Aanvraag - Iris Siemerink",
            receiver={
                "name": "Iris Siemerink",
                "street": "Kerkstraat",
                "house_number": "12",
                "postcode": "1234AB",
                "city": "Enter",
                "country": "NL",
            },
            stage_name="Verzonden/meegegeven",
        )
        resolver = FakeResolver(lead)
        dm_client = FakeDeliveryMatchClient()

        result = process_sample_mention(
            SampleMention(raw_text="Iris Siemerink", candidates=["Iris Siemerink"]),
            resolver=resolver,
            dm_client=dm_client,
            dm_client_id="101276",
            pickup_date=None,
            reference="sample",
            execute_write=True,
            force=False,
            duplicate_log={},
            print_payload=False,
            processed_stage_name="Verzonden/meegegeven",
        )

        self.assertEqual(result["status"], "skipped_stage")
        self.assertFalse(dm_client.insert_called)
        self.assertIsNone(resolver.moved_to_stage)

    def test_swap_postcode_city_when_postcode_field_holds_city(self) -> None:
        postcode, city = swap_postcode_city_if_inverted("Westerbork", "9431AJ")
        self.assertEqual((postcode, city), ("9431AJ", "Westerbork"))

        unchanged = swap_postcode_city_if_inverted("7468DC", "Enter")
        self.assertEqual(unchanged, ("7468DC", "Enter"))

    def test_choose_single_lead_prefers_open_stage_over_already_sent(self) -> None:
        class FakeClient:
            def fields_get(self, model: str) -> dict:
                return {"name": {}, "stage_id": {}}

        resolver = SampleLeadResolver(FakeClient())
        leads = [
            {"id": 7049, "name": "Re: Sample Aanvraag - Chantal Rijper", "stage_id": [4, "Te versturen/binnen"], "create_date": "2026-05-08 08:53:56"},
            {"id": 6887, "name": "Re: Sample Aanvraag - Chantal Rijper", "stage_id": [5, "Verzonden/meegegeven"], "create_date": "2026-05-02 10:22:06"},
        ]

        chosen = resolver.choose_single_lead("Chantal Rijper", leads)

        self.assertEqual(chosen["id"], 7049)

    def test_parse_sample_request_body_extracts_address_fields(self) -> None:
        body = (
            "<p>Sample Aanvraag</p>"
            "<p>&nbsp;Mendy Kogelman</p>"
            "<p>mendykogelman@gmail.com</p>"
            "Bedrijf (Optioneel) "
            "Adres (Verplicht) "
            "Straat: Kruisbergseweg "
            "Huisnummer: 144A "
            "Plaats: Doetinchem "
            "Postcode: 7009 BT "
            "Land: Netherlands "
            "Benodigd aantal m2 (Optioneel) "
            "Opmerking (Optioneel) "
            "You can edit this submission ..."
        )

        parsed = parse_sample_request_body(body)

        self.assertEqual(parsed["street"], "Kruisbergseweg")
        self.assertEqual(parsed["house_number"], "144")
        self.assertEqual(parsed["house_number_ext"], "A")
        self.assertEqual(parsed["postcode"], "7009 BT")
        self.assertEqual(parsed["city"], "Doetinchem")
        self.assertEqual(parsed["country"], "Netherlands")

    def test_live_send_moves_odoo_stage_after_insert(self) -> None:
        lead = SampleLead(
            id=71318,
            sample_name="Iris Siemerink",
            lead_name="Re: Sample Aanvraag - Iris Siemerink",
            receiver={
                "name": "Iris Siemerink",
                "street": "Kerkstraat",
                "house_number": "12",
                "postcode": "1234AB",
                "city": "Enter",
                "country": "NL",
            },
            stage_name="Te versturen/binnen",
        )
        resolver = FakeResolver(lead)
        dm_client = FakeDeliveryMatchClient()

        result = process_sample_mention(
            SampleMention(raw_text="Iris Siemerink", candidates=["Iris Siemerink"]),
            resolver=resolver,
            dm_client=dm_client,
            dm_client_id="101276",
            pickup_date=None,
            reference="sample",
            execute_write=True,
            force=False,
            duplicate_log={},
            print_payload=False,
            processed_stage_name="Verzonden/meegegeven",
        )

        self.assertEqual(result["status"], "sent")
        self.assertTrue(dm_client.insert_called)
        self.assertEqual(resolver.moved_to_stage, (71318, "Verzonden/meegegeven"))


if __name__ == "__main__":
    unittest.main()
