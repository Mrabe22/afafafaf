from __future__ import annotations

import unittest

from dm_odoo_test.odoo_client import split_street_house
from dm_odoo_test.sample_payload import build_sample_shipment_payload, sample_order_number


class SamplePayloadTests(unittest.TestCase):
    def test_builds_sample_payload_from_crm_receiver(self) -> None:
        payload = build_sample_shipment_payload(
            {
                "name": "Iris Siemerink",
                "street": "Kerkstraat",
                "house_number": "12",
                "postcode": "1234AB",
                "city": "Enter",
                "country": "NL",
                "email": "iris@example.test",
            },
            client_id="101276",
            order_number=sample_order_number(71318, "Iris Siemerink"),
            reference="sample",
        )

        self.assertEqual(payload["shipment"]["reference"], "sample")
        self.assertEqual(payload["shipment"]["orderNumber"], "SAMPLE-71318")
        self.assertEqual(payload["customer"]["address"]["name"], "Iris Siemerink")
        self.assertEqual(payload["customer"]["address"]["houseNr"], "12")
        self.assertEqual(payload["carrier"]["name"], "DHLPARCEL")
        self.assertEqual(payload["serviceLevel"]["name"], "product[DFY]options[DOOR]")
        self.assertEqual(payload["packages"]["package"][0]["weight"], 1.0)
        self.assertEqual(payload["packages"]["package"][0]["length"], 1.0)
        self.assertEqual(payload["quote"]["product"][0]["SKU"], "SAMPLE")

    def test_splits_street_house_number(self) -> None:
        self.assertEqual(split_street_house("Correllistraat 17"), ("Correllistraat", "17", ""))
        self.assertEqual(split_street_house("Vonderweg 25 A"), ("Vonderweg", "25A", ""))


if __name__ == "__main__":
    unittest.main()
