from __future__ import annotations

import unittest

from dm_odoo_test.sample_parser import extract_sample_mentions, extract_sample_names


class SampleParserTests(unittest.TestCase):
    def test_extracts_sample_names_from_clean_ocr_lines(self) -> None:
        text = """
        Re: Sample Aanvraag - Iris Siemerink
        Re: Sample Aanvraag - Lotte Spek
        Re: Sample Aanvraag - Stefanie de Groot
        """

        self.assertEqual(
            extract_sample_names(text),
            ["Iris Siemerink", "Lotte Spek", "Stefanie de Groot"],
        )

    def test_candidates_include_particle_name_variant(self) -> None:
        mention = extract_sample_mentions("Re: Sample Aanvraag - Stefanie de Groot Marazzi Lume")[0]

        self.assertIn("Stefanie de Groot", mention.candidates)
        self.assertNotIn("Stefanie de Groot Marazzi", mention.candidates)

    def test_prefers_short_candidate_when_product_text_is_on_same_line(self) -> None:
        mention = extract_sample_mentions(
            "Re: Sample Aanvraag - Iris Siemerink Marazzi Lume musk 6x24"
        )[0]

        self.assertEqual(mention.candidates[0], "Iris Siemerink")

    def test_recovers_name_from_next_ocr_line_after_fuzzy_marker(self) -> None:
        text = """
        Re: Sample Aanvra
        - Iris Siemerink
        Re: Sample Aanvraa
        - Lotte S ek
        Re: Sample Aanvraag - Stefanie de
        Groot
        Marazzi Lume musk 6x24
        """

        self.assertEqual(
            extract_sample_names(text),
            ["Iris Siemerink", "Lotte S", "Stefanie de Groot"],
        )


if __name__ == "__main__":
    unittest.main()
