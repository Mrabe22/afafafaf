from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dm_odoo_test.payload_builder import (  # noqa: E402
    MappingError,
    build_insert_shipment_payload,
    load_json,
    should_send_to_deliverymatch,
    validate_payload,
)


class PayloadBuilderTests(unittest.TestCase):
    def setUp(self) -> None:
        self.fixture = load_json(ROOT / "data" / "odoo_order_ord18026.json")

    def test_builds_deliverymatch_payload_from_odoo_delivery(self) -> None:
        payload = build_insert_shipment_payload(self.fixture, "101276")

        self.assertEqual(payload["client"]["id"], 101276)
        self.assertEqual(payload["shipment"]["orderNumber"], "ORD18026")
        self.assertEqual(payload["shipment"]["reference"], "S23223")
        self.assertEqual(payload["customer"]["address"]["name"], "Tina Winkler")
        self.assertEqual(payload["customer"]["address"]["country"], "DE")
        self.assertEqual(payload["sender"]["address"]["city"], "Enter")
        self.assertEqual(payload["carrier"]["name"], "DHLPARCEL")
        self.assertEqual(payload["serviceLevel"]["name"], "product[DFY]options[DOOR]")
        self.assertEqual(len(payload["packages"]["package"]), 1)
        self.assertEqual(payload["packages"]["package"][0]["weight"], 10.0)
        self.assertEqual(len(payload["quote"]["product"]), 1)
        self.assertEqual(payload["quote"]["product"][0]["SKU"], "R9QQ")
        self.assertEqual(validate_payload(payload), [])

    def test_only_dhl_deliveries_are_eligible(self) -> None:
        not_dhl = copy.deepcopy(self.fixture)
        not_dhl["stock_picking"]["carrier_code"] = "POSTNL"
        not_dhl["stock_picking"]["carrier_name"] = "PostNL"

        self.assertFalse(should_send_to_deliverymatch(not_dhl))
        with self.assertRaises(MappingError):
            build_insert_shipment_payload(not_dhl, "101276")

    def test_existing_deliverymatch_shipment_blocks_duplicate_insert(self) -> None:
        already_sent = copy.deepcopy(self.fixture)
        already_sent["stock_picking"]["deliverymatch"]["shipment_id"] = 27099574

        with self.assertRaises(MappingError):
            build_insert_shipment_payload(already_sent, "101276")


if __name__ == "__main__":
    unittest.main()

