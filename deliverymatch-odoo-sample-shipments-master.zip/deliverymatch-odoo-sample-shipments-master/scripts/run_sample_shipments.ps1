param(
    [Parameter(Mandatory = $true)]
    [string[]]$Image,

    [string]$Only = "",

    [string]$ClientId = "101276",

    [ValidateSet("prod", "test")]
    [string]$Env = "prod",

    [switch]$ExecuteWrite,

    [switch]$PrintPayloads
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "Kopieer nu je DeliveryMatch API key naar je clipboard en typ daarna OK."
Write-Host "De key wordt tijdelijk uit het clipboard gelezen en niet opgeslagen."
$confirmation = Read-Host "Typ OK als de API key op je clipboard staat"
if ($confirmation -ne "OK") {
    throw "Afgebroken. De API key is niet uit het clipboard gelezen."
}

$apiKey = (Get-Clipboard -Raw).Trim()
if (-not $apiKey) {
    throw "Clipboard is leeg. Kopieer eerst de API key en probeer opnieuw."
}

try {
    $env:DELIVERYMATCH_CLIENT_ID = $ClientId
    $env:DELIVERYMATCH_API_KEY = $apiKey
    $env:DELIVERYMATCH_ENV = $Env

    $argsList = @(
        "-m", "dm_odoo_test.cli",
        "create-sample-shipments",
        "--env", $Env,
        "--client-id", $ClientId
    )
    foreach ($imagePath in $Image) {
        $argsList += @("--image", $imagePath)
    }
    if ($Only) {
        $argsList += @("--only", $Only)
    }
    if ($ExecuteWrite) {
        $argsList += "--execute-write"
    }
    if ($PrintPayloads) {
        $argsList += "--print-payloads"
    }
    python @argsList
    exit $LASTEXITCODE
}
finally {
    Remove-Item Env:\DELIVERYMATCH_CLIENT_ID -ErrorAction SilentlyContinue
    Remove-Item Env:\DELIVERYMATCH_API_KEY -ErrorAction SilentlyContinue
    Remove-Item Env:\DELIVERYMATCH_ENV -ErrorAction SilentlyContinue
    $apiKey = $null
}
