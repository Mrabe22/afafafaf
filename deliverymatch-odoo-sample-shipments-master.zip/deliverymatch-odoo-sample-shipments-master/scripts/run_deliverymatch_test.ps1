param(
    [ValidateSet("me", "insert-shipment")]
    [string]$Command = "me",

    [string]$ClientId = "101276",

    [ValidateSet("prod", "test")]
    [string]$Env = "prod",

    [string]$Payload = "outputs\ord18026_insert_payload.json",

    [switch]$ExecuteWrite
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "Kopieer nu je DeliveryMatch API key naar je clipboard en typ daarna OK."
Write-Host "De key wordt tijdelijk uit het clipboard gelezen en niet opgeslagen."
$confirmation = Read-Host "Typ OK als de API key op je clipboard staat"
if ($confirmation -ne "OK") {
    throw "Afgebroken. De API key is niet uit het clipboard gelezen."
}

$apiKey = (Get-Clipboard -Raw).Trim()
if (-not $apiKey) {
    throw "Clipboard is leeg. Kopieer eerst de API key en probeer opnieuw."
}

try {
    $env:DELIVERYMATCH_CLIENT_ID = $ClientId
    $env:DELIVERYMATCH_API_KEY = $apiKey
    $env:DELIVERYMATCH_ENV = $Env

    if ($Command -eq "me") {
        python -m dm_odoo_test.cli me --env $Env --client-id $ClientId
        exit $LASTEXITCODE
    }

    $argsList = @("-m", "dm_odoo_test.cli", "insert-shipment", "--env", $Env, "--client-id", $ClientId, "--payload", $Payload)
    if ($ExecuteWrite) {
        $argsList += "--execute-write"
    }
    python @argsList
    exit $LASTEXITCODE
}
finally {
    Remove-Item Env:\DELIVERYMATCH_CLIENT_ID -ErrorAction SilentlyContinue
    Remove-Item Env:\DELIVERYMATCH_API_KEY -ErrorAction SilentlyContinue
    Remove-Item Env:\DELIVERYMATCH_ENV -ErrorAction SilentlyContinue
    $apiKey = $null
}

