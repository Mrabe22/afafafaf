from __future__ import annotations

import datetime as dt
import os
import re
from typing import Any

from .payload_builder import build_contact, deep_get, normalize_country, normalize_postcode


class SamplePayloadError(ValueError):
    """Raised when a CRM lead cannot safely become a sample shipment."""


DEFAULT_SENDER = {
    "company_name": "Tegelfabriek-Nederland",
    "name": "Tegelfabriek-Nederland",
    "street": "Vonderweg",
    "house_number": "25",
    "postcode": "7468DC",
    "city": "Enter",
    "country": "NL",
    "email": "info@tegelfabriek-nederland.nl",
    "phone": "",
}

DEFAULT_SAMPLE = {
    "carrier_name": "DHLPARCEL",
    "service_level": "product[DFY]options[DOOR]",
    "language": "nl",
    "delivery_time_from": "08:00",
    "delivery_time_to": "17:00",
    "package_description": "Goods",
    "product_description": "Sample",
    "package_type": "COLLO",
    "weight": 1.0,
    "length": 1.0,
    "width": 1.0,
    "height": 1.0,
}


def build_sample_shipment_payload(
    receiver: dict[str, Any],
    *,
    client_id: str,
    order_number: str,
    reference: str = "sample",
    pickup_date: dt.date | None = None,
) -> dict[str, Any]:
    if not client_id:
        raise SamplePayloadError("DeliveryMatch client id ontbreekt.")
    if not order_number:
        raise SamplePayloadError("DeliveryMatch orderNumber ontbreekt.")

    package = build_sample_package()
    product = build_sample_product(package)
    sender = configured_sender()

    shipment_block: dict[str, Any] = {
        "status": "new",
        "orderNumber": order_number,
        "reference": reference,
        "language": os.environ.get("SAMPLE_SHIPMENT_LANGUAGE", DEFAULT_SAMPLE["language"]),
        "currency": "EUR",
        "deliveryTimeFrom": os.environ.get("SAMPLE_SHIPMENT_TIME_FROM", DEFAULT_SAMPLE["delivery_time_from"]),
        "deliveryTimeTo": os.environ.get("SAMPLE_SHIPMENT_TIME_TO", DEFAULT_SAMPLE["delivery_time_to"]),
        "inbound": False,
    }
    if pickup_date is not None:
        shipment_block["deliveryDate"] = pickup_date.isoformat()

    payload = {
        "client": {
            "id": int(client_id) if str(client_id).isdigit() else str(client_id),
            "action": os.environ.get("SAMPLE_SHIPMENT_ACTION", "book"),
            "method": os.environ.get("SAMPLE_SHIPMENT_METHOD", "lowprice"),
            "filter": False,
            "transportlabel": False,
            "copy": False,
        },
        "sender": {
            "address": build_deliverymatch_address(sender, sender=True),
            "contact": build_contact(sender),
        },
        "customer": {
            "address": build_deliverymatch_address(receiver, sender=False),
            "contact": build_contact(receiver),
        },
        "shipment": shipment_block,
        "carrier": {
            "name": os.environ.get("SAMPLE_SHIPMENT_CARRIER", DEFAULT_SAMPLE["carrier_name"]),
        },
        "serviceLevel": {
            "name": os.environ.get("SAMPLE_SHIPMENT_SERVICE_LEVEL", DEFAULT_SAMPLE["service_level"]),
        },
        "packages": {
            "package": [package],
        },
        "quote": {
            "product": [product],
        },
        "fragileGoods": False,
        "dangerousGoods": False,
        "colli": 1,
        "priceIncl": 0.0,
        "priceExcl": 0.0,
        "weight": package["weight"],
    }
    errors = validate_sample_payload(payload)
    if errors:
        raise SamplePayloadError("; ".join(errors))
    return payload


def build_sample_package() -> dict[str, Any]:
    return {
        "weight": env_float("SAMPLE_SHIPMENT_WEIGHT_KG", DEFAULT_SAMPLE["weight"]),
        "width": env_float("SAMPLE_SHIPMENT_WIDTH_CM", DEFAULT_SAMPLE["width"]),
        "length": env_float("SAMPLE_SHIPMENT_LENGTH_CM", DEFAULT_SAMPLE["length"]),
        "height": env_float("SAMPLE_SHIPMENT_HEIGHT_CM", DEFAULT_SAMPLE["height"]),
        "packageNum": 1,
        "description": os.environ.get("SAMPLE_SHIPMENT_PACKAGE_DESCRIPTION", DEFAULT_SAMPLE["package_description"]),
        "type": os.environ.get("SAMPLE_SHIPMENT_PACKAGE_TYPE", DEFAULT_SAMPLE["package_type"]),
    }


def build_sample_product(package: dict[str, Any]) -> dict[str, Any]:
    return {
        "SKU": "SAMPLE",
        "quantity": 1,
        "value": 0.0,
        "weight": package["weight"],
        "length": package["length"],
        "width": package["width"],
        "height": package["height"],
        "description": os.environ.get("SAMPLE_SHIPMENT_PRODUCT_DESCRIPTION", DEFAULT_SAMPLE["product_description"]),
        "packageNum": 1,
    }


def build_deliverymatch_address(data: dict[str, Any], *, sender: bool) -> dict[str, Any]:
    street = first_text(data.get("street"), data.get("address1"))
    house_number = first_text(data.get("house_number"), data.get("houseNr"))
    house_ext = first_text(data.get("house_number_ext"), data.get("houseNrExt"))
    address1 = " ".join(part for part in [street, house_number, house_ext] if part).strip()
    if not address1:
        raise SamplePayloadError("Adresregel ontbreekt.")

    address: dict[str, Any] = {
        "address1": address1,
        "street": street,
        "houseNr": house_number,
        "houseNrExt": house_ext,
        "postcode": normalize_postcode(data.get("postcode") or data.get("zip")),
        "city": first_text(data.get("city")),
        "country": normalize_country(data.get("country")),
    }
    company_name = first_text(data.get("company_name"), data.get("companyName"))
    name = first_text(data.get("name"), company_name)
    if sender:
        address["companyName"] = company_name or name
        address["name"] = name or company_name
    else:
        address["name"] = name
        if company_name:
            address["companyName"] = company_name
    return address


def validate_sample_payload(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for path in [
        "client.id",
        "sender.address.address1",
        "sender.address.postcode",
        "sender.address.city",
        "sender.address.country",
        "customer.address.name",
        "customer.address.address1",
        "customer.address.postcode",
        "customer.address.city",
        "customer.address.country",
        "shipment.orderNumber",
        "shipment.reference",
        "packages.package",
        "quote.product",
    ]:
        value = deep_get(payload, path)
        if value in (None, "", []):
            errors.append(f"Ontbrekend verplicht veld: {path}")

    postcode = str(deep_get(payload, "customer.address.postcode") or "")
    country = normalize_country(deep_get(payload, "customer.address.country"))
    if country == "NL" and not re.match(r"^[1-9]\d{3}\s?[A-Z]{2}$", postcode):
        errors.append(f"Ontvangerpostcode lijkt geen geldige Nederlandse postcode: {postcode}")
    return errors


def configured_sender() -> dict[str, Any]:
    sender = dict(DEFAULT_SENDER)
    env_map = {
        "company_name": "SAMPLE_SENDER_COMPANY",
        "name": "SAMPLE_SENDER_NAME",
        "street": "SAMPLE_SENDER_STREET",
        "house_number": "SAMPLE_SENDER_HOUSE_NUMBER",
        "house_number_ext": "SAMPLE_SENDER_HOUSE_NUMBER_EXT",
        "postcode": "SAMPLE_SENDER_POSTCODE",
        "city": "SAMPLE_SENDER_CITY",
        "country": "SAMPLE_SENDER_COUNTRY",
        "email": "SAMPLE_SENDER_EMAIL",
        "phone": "SAMPLE_SENDER_PHONE",
    }
    for key, env_name in env_map.items():
        if os.environ.get(env_name):
            sender[key] = os.environ[env_name]
    return sender


def sample_order_number(lead_id: int | str, sample_name: str) -> str:
    lead_part = str(lead_id).strip() if lead_id else slugify(sample_name)
    return f"SAMPLE-{lead_part}"


def slugify(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "-", value).strip("-")
    return text[:40] or "sample"


def first_text(*values: Any) -> str:
    for value in values:
        if value is False or value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def env_float(name: str, default: float) -> float:
    value = os.environ.get(name)
    if not value:
        return float(default)
    try:
        number = float(value.replace(",", "."))
    except ValueError as exc:
        raise SamplePayloadError(f"{name} moet numeriek zijn.") from exc
    if number <= 0:
        raise SamplePayloadError(f"{name} moet groter zijn dan 0.")
    return round(number, 3)
