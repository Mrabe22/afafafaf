from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any


class OCRError(RuntimeError):
    """Raised when no usable OCR backend can read the sample list image."""


def image_to_text(
    image_path: str | Path,
    *,
    backend: str = "auto",
    language: str = "nl-NL",
    auto_rotate: bool = True,
) -> str:
    path = Path(image_path)
    if not path.exists():
        raise OCRError(f"Afbeelding niet gevonden: {path}")

    candidates = rotated_candidates(path) if auto_rotate else [(0, path, None)]
    best_text = ""
    best_score = -1
    cleanup_paths: list[Path] = []
    try:
        for angle, candidate_path, cleanup_path in candidates:
            if cleanup_path:
                cleanup_paths.append(cleanup_path)
            text = run_ocr(candidate_path, backend=backend, language=language) or ""
            score = score_ocr_text(text)
            if score > best_score:
                best_text = text
                best_score = score
            if angle == 0 and not auto_rotate:
                break
        if not best_text.strip():
            raise OCRError("OCR gaf geen tekst terug.")
        return best_text
    finally:
        for cleanup_path in cleanup_paths:
            cleanup_path.unlink(missing_ok=True)


def run_ocr(path: Path, *, backend: str, language: str) -> str:
    if backend in {"auto", "rapidocr"} and has_rapidocr():
        try:
            return rapidocr_ocr(path)
        except OCRError:
            if backend == "rapidocr":
                raise
    if backend in {"auto", "windows"} and os.name == "nt":
        try:
            return windows_ocr(path, language=language)
        except OCRError:
            if backend == "windows":
                raise
    if backend in {"auto", "tesseract"} and shutil.which("tesseract"):
        return tesseract_ocr(path, language=language)
    raise OCRError(
        "Geen OCR backend beschikbaar. Installeer rapidocr-onnxruntime, gebruik Windows OCR op Windows of installeer tesseract, "
        "of geef eerder gemaakte OCR-tekst mee met --ocr-text."
    )


def has_rapidocr() -> bool:
    try:
        import rapidocr_onnxruntime  # noqa: F401
    except ImportError:
        return False
    return True


def rapidocr_ocr(path: Path) -> str:
    try:
        from rapidocr_onnxruntime import RapidOCR
    except ImportError as exc:
        raise OCRError("rapidocr-onnxruntime is niet geinstalleerd.") from exc

    engine = get_rapidocr_engine()
    result, _elapsed = engine(str(path))
    lines: list[str] = []
    for item in result or []:
        text = rapidocr_item_text(item)
        if text:
            lines.append(text)
    return "\n".join(lines)


_RAPIDOCR_ENGINE: Any | None = None


def get_rapidocr_engine() -> Any:
    global _RAPIDOCR_ENGINE
    if _RAPIDOCR_ENGINE is None:
        from rapidocr_onnxruntime import RapidOCR

        _RAPIDOCR_ENGINE = RapidOCR()
    return _RAPIDOCR_ENGINE


def rapidocr_item_text(item: Any) -> str:
    try:
        value = item[1]
    except (IndexError, TypeError):
        return ""
    return str(value).strip()


def windows_ocr(path: Path, *, language: str) -> str:
    script = Path(__file__).resolve().parents[2] / "scripts" / "windows_ocr.ps1"
    if not script.exists():
        raise OCRError(f"Windows OCR script ontbreekt: {script}")
    command = [
        "powershell",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(script),
        "-ImagePath",
        str(path),
        "-Language",
        language,
    ]
    completed = subprocess.run(
        command,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0:
        raise OCRError((completed.stderr or completed.stdout or "Windows OCR mislukt.").strip())
    return completed.stdout


def tesseract_ocr(path: Path, *, language: str) -> str:
    tesseract_language = "nld+eng" if language.lower().startswith("nl") else "eng"
    command = ["tesseract", str(path), "stdout", "-l", tesseract_language]
    completed = subprocess.run(command, text=True, encoding="utf-8", errors="replace", capture_output=True, check=False)
    if completed.returncode != 0:
        raise OCRError((completed.stderr or completed.stdout or "Tesseract OCR mislukt.").strip())
    return completed.stdout


def rotated_candidates(path: Path) -> list[tuple[int, Path, Path | None]]:
    try:
        from PIL import Image, ImageOps
    except ImportError:
        return [(0, path, None)]

    candidates: list[tuple[int, Path, Path | None]] = [(0, path, None)]
    with Image.open(path) as image:
        normalized = ImageOps.exif_transpose(image)
        for angle in (90, 180, 270):
            rotated = normalized.rotate(angle, expand=True)
            handle = tempfile.NamedTemporaryFile(prefix=f"sample-ocr-{angle}-", suffix=".png", delete=False)
            handle.close()
            rotated.save(handle.name)
            candidates.append((angle, Path(handle.name), Path(handle.name)))

        for angle in (0, 90, 180, 270):
            rotated = normalized.rotate(angle, expand=True)
            enhanced = enhance_for_ocr(rotated)
            handle = tempfile.NamedTemporaryFile(prefix=f"sample-ocr-enhanced-{angle}-", suffix=".png", delete=False)
            handle.close()
            enhanced.save(handle.name)
            candidates.append((angle, Path(handle.name), Path(handle.name)))
    return candidates


def enhance_for_ocr(image: Any) -> Any:
    from PIL import Image, ImageEnhance, ImageFilter, ImageOps

    processed = ImageOps.grayscale(image)
    processed = ImageOps.autocontrast(processed)
    processed = ImageEnhance.Contrast(processed).enhance(2.0)
    processed = processed.filter(ImageFilter.SHARPEN)
    scale = 2 if max(processed.size) < 3500 else 1
    if scale > 1:
        processed = processed.resize((processed.width * scale, processed.height * scale), Image.Resampling.LANCZOS)
    return processed


def score_ocr_text(text: str) -> int:
    if not text:
        return 0
    lowered = text.casefold()
    score = lowered.count("sample") * 10
    score += lowered.count("sampie") * 8
    score += lowered.count("samp") * 4
    score += lowered.count("aanvraag") * 10
    score += lowered.count("aanvra") * 8
    score += lowered.count("re:") * 3
    score += min(len(text.split()), 200)
    return score
