from __future__ import annotations

import re
from dataclasses import dataclass


SAMPLE_MARKER_RE = re.compile(
    r"(?:^|\b)R[eéi]\s*[:\-]?\s*S[a-z]{3,8}\s*A[a-z]{3,12}\s*(?:[-:]\s*)?(?P<tail>.*)$",
    re.IGNORECASE,
)
SAMPLE_REQUEST_RE = re.compile(
    r"(?:\bR[eéi]\s*[:\-]?\s*)?S[a-z]{3,8}\s*A[a-z]{3,12}\s*[-:]\s*(?P<tail>[^\r\n]+)",
    re.IGNORECASE,
)

STOP_WORDS = {
    "marazzi",
    "ragno",
    "workshop",
    "zelige",
    "zellige",
    "lume",
    "look",
    "glossy",
    "natural",
    "rice",
    "bone",
    "musk",
    "gesso",
    "bianco",
    "verde",
    "pink",
    "beige",
    "cotton",
    "cm",
    "https",
    "aanvraag",
    "aanvra",
    "sample",
    "re",
    "verkoopfans",
    "verkoopkans",
    "www",
}
NAME_PARTICLES = {
    "de",
    "den",
    "der",
    "van",
    "von",
    "du",
    "ter",
    "ten",
    "het",
    "op",
    "t",
    "la",
    "le",
}
SALES_OPPORTUNITY_WORD_RE = re.compile(r"\bVerkoop(?:fans|kans)\b", re.IGNORECASE)


@dataclass(frozen=True)
class SampleMention:
    raw_text: str
    candidates: list[str]

    @property
    def best_name(self) -> str:
        return self.candidates[0] if self.candidates else ""


def extract_sample_mentions(text: str) -> list[SampleMention]:
    normalized = normalize_ocr_text(text)
    has_line_structure = any(line.strip() for line in normalized.splitlines()[1:])
    if has_line_structure or "\n" in normalized:
        return dedupe_mentions(extract_inline_ordered_mentions(normalized))

    mentions: list[SampleMention] = []
    for match in SAMPLE_REQUEST_RE.finditer(normalized):
        raw_tail = clean_tail(match.group("tail"))
        candidates = sample_name_candidates(raw_tail)
        if candidates:
            mentions.append(SampleMention(raw_text=raw_tail, candidates=candidates))
    mentions.extend(extract_sales_opportunity_mentions(normalized))
    mentions.extend(extract_bare_name_mentions_from_lines(normalized.splitlines()))
    return dedupe_mentions(mentions)


def extract_inline_ordered_mentions(text: str) -> list[SampleMention]:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    mentions: list[SampleMention] = []
    index = 0
    while index < len(lines):
        line = lines[index]

        marker = SAMPLE_MARKER_RE.search(line)
        if marker:
            collected: list[str] = []
            tail = clean_tail(marker.group("tail"))
            if tail:
                collected.append(tail)
            lookahead = index + 1
            while should_collect_more_name_parts(collected) and lookahead < len(lines):
                next_line = lines[lookahead]
                if SAMPLE_MARKER_RE.search(next_line):
                    break
                next_tail = clean_tail(next_line)
                if not next_tail:
                    lookahead += 1
                    continue
                if not looks_like_name_fragment(next_tail):
                    break
                collected.append(next_tail)
                lookahead += 1
            raw_tail = clean_tail(" ".join(collected))
            primary_candidates = sample_name_candidates(raw_tail)
            primary_mention = (
                SampleMention(raw_text=raw_tail, candidates=primary_candidates)
                if primary_candidates
                else None
            )
            sales_mention = sales_opportunity_mention_from_tail(raw_tail)
            if primary_mention:
                mentions.append(primary_mention)
            middle_mentions = extract_middle_bare_names(raw_tail, primary_mention, sales_mention)
            for m in middle_mentions:
                mentions.append(m)
            if sales_mention:
                mentions.append(sales_mention)
            index = max(index + 1, lookahead)
            continue

        cleaned_line = clean_tail(line)
        if SALES_OPPORTUNITY_WORD_RE.search(cleaned_line):
            leading_bare, sales_mention = split_leading_bare_and_sales(cleaned_line)
            for bare_mention in leading_bare:
                mentions.append(bare_mention)
            if sales_mention:
                mentions.append(sales_mention)
            index += 1
            continue

        bare = bare_name_mention_from_line(line)
        if bare:
            mentions.append(bare)

        index += 1
    return mentions


def split_leading_bare_and_sales(line: str) -> tuple[list[SampleMention], SampleMention | None]:
    match = SALES_OPPORTUNITY_WORD_RE.search(line)
    if not match:
        return [], None
    sales_mention = sales_opportunity_mention_from_tail(line)
    if not sales_mention:
        return [], None
    selected_tokens = sales_mention.best_name.split()
    before = re.sub(r"['’]s\s*$", "", line[: match.start()].rstrip())
    leading_tokens = [strip_possessive(token) for token in tokenize_tail(before)]
    leading_tokens = [token for token in leading_tokens if token]
    drop = len(selected_tokens)
    if drop and leading_tokens[-drop:] == selected_tokens:
        leading_tokens = leading_tokens[:-drop]
    bare_mentions: list[SampleMention] = []
    if 2 <= len(leading_tokens) <= 4 and looks_like_name(leading_tokens):
        name = " ".join(leading_tokens)
        candidates = sample_name_candidates(name)
        if candidates:
            bare_mentions.append(SampleMention(raw_text=name, candidates=candidates))
    return bare_mentions, sales_mention


def extract_middle_bare_names(
    raw_tail: str,
    primary: SampleMention | None,
    sales: SampleMention | None,
) -> list[SampleMention]:
    tokens = tokenize_tail(raw_tail)
    if not tokens:
        return []
    head = primary.best_name.split() if primary else []
    tail = sales.best_name.split() if sales else []
    drop_head = len(head) if head and tokens[: len(head)] == head else 0
    drop_tail = len(tail) if tail and tokens[-len(tail):] == tail else 0
    middle = tokens[drop_head : len(tokens) - drop_tail] if drop_tail else tokens[drop_head:]
    middle = [strip_possessive(token) for token in middle]
    middle = [token for token in middle if token]
    mentions: list[SampleMention] = []
    chunk: list[str] = []
    for token in middle:
        if token.lower() in NAME_PARTICLES:
            if chunk:
                chunk.append(token)
            continue
        is_cap = token[:1].isupper() or token.isupper()
        if not is_cap and not (token.isalpha() and len(token) >= 2):
            if 2 <= len(chunk) <= 4 and looks_like_name(chunk):
                name = " ".join(chunk)
                cands = sample_name_candidates(name)
                if cands:
                    mentions.append(SampleMention(raw_text=name, candidates=cands))
            chunk = []
            continue
        if chunk and any(t.lower() in NAME_PARTICLES for t in chunk[-1:]):
            chunk.append(token)
            continue
        if len(chunk) >= 2:
            if looks_like_name(chunk):
                name = " ".join(chunk)
                cands = sample_name_candidates(name)
                if cands:
                    mentions.append(SampleMention(raw_text=name, candidates=cands))
            chunk = [token]
        else:
            chunk.append(token)
    if 2 <= len(chunk) <= 4 and looks_like_name(chunk):
        name = " ".join(chunk)
        cands = sample_name_candidates(name)
        if cands:
            mentions.append(SampleMention(raw_text=name, candidates=cands))
    return mentions


def bare_name_mention_from_line(line: str) -> SampleMention | None:
    tail = clean_tail(line)
    if not tail or len(tail) > 60:
        return None
    tokens = tokenize_tail(tail)
    if len(tokens) < 2 or len(tokens) > 4:
        return None
    if any(token.lower() in STOP_WORDS for token in tokens):
        return None
    if not looks_like_name(tokens):
        return None
    name = " ".join(tokens)
    candidates = sample_name_candidates(name)
    if not candidates:
        return None
    return SampleMention(raw_text=name, candidates=candidates)


def extract_bare_name_mentions_from_lines(lines: list[str]) -> list[SampleMention]:
    mentions: list[SampleMention] = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        if SAMPLE_MARKER_RE.search(stripped) or SALES_OPPORTUNITY_WORD_RE.search(stripped):
            continue
        bare = bare_name_mention_from_line(stripped)
        if bare:
            mentions.append(bare)
    return mentions


def extract_sample_names(text: str) -> list[str]:
    return [mention.best_name for mention in extract_sample_mentions(text)]


def normalize_ocr_text(text: str) -> str:
    replacements = {
        "\u2013": "-",
        "\u2014": "-",
        "\u2212": "-",
        "\u00a0": " ",
        "|": " ",
    }
    normalized = text
    for old, new in replacements.items():
        normalized = normalized.replace(old, new)
    normalized = re.sub(r"(?i)\bRe\s*:\s*Sample\s*Aanvraag", "Re: Sample Aanvraag ", normalized)
    normalized = re.sub(r"(?i)\bRe\s*Sample\s*Aanvraag", "Re: Sample Aanvraag ", normalized)
    normalized = re.sub(r"(?i)\bRe\s*:\s*SampleAanvraag", "Re: Sample Aanvraag ", normalized)
    normalized = re.sub(r"(?i)\bRe\s*SampleAanvraag", "Re: Sample Aanvraag ", normalized)
    normalized = split_inline_sample_markers(normalized)
    normalized = re.sub(r"(verkoop(?:kans|fans))\s+(?=\S)", r"\1\n", normalized, flags=re.IGNORECASE)
    normalized = split_camel_case_names(normalized)
    return normalized


def split_inline_sample_markers(text: str) -> str:
    marker = r"R[eÃ©i]\s*[:\-]?\s*S[a-z]{3,8}\s*A[a-z]{3,12}\s*(?:[-:]\s*)?"
    return re.sub(rf"([^\r\n])\s+(?={marker})", r"\1\n", text, flags=re.IGNORECASE)


def split_camel_case_names(text: str) -> str:
    # OCR sometimes removes spaces inside the CRM name, for example
    # "Re:SampleAanvraagLara Peeters". Restore only clear lower->upper joins.
    return re.sub(r"(?<=[a-zà-öø-ÿ])(?=[A-ZÀ-ÖØ-Þ])", " ", text)


def extract_line_sample_mentions(text: str) -> list[SampleMention]:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    mentions: list[SampleMention] = []
    index = 0
    while index < len(lines):
        line = lines[index]
        match = SAMPLE_MARKER_RE.search(line)
        if not match:
            index += 1
            continue

        collected: list[str] = []
        tail = clean_tail(match.group("tail"))
        if tail:
            collected.append(tail)

        lookahead = index + 1
        while should_collect_more_name_parts(collected) and lookahead < len(lines):
            next_line = lines[lookahead]
            if SAMPLE_MARKER_RE.search(next_line):
                break
            next_tail = clean_tail(next_line)
            if not next_tail:
                lookahead += 1
                continue
            if not looks_like_name_fragment(next_tail):
                break
            collected.append(next_tail)
            lookahead += 1

        raw_tail = clean_tail(" ".join(collected))
        candidates = sample_name_candidates(raw_tail)
        if candidates:
            mentions.append(SampleMention(raw_text=raw_tail, candidates=candidates))
        sales_mention = sales_opportunity_mention_from_tail(raw_tail)
        if sales_mention:
            mentions.append(sales_mention)

        index = max(index + 1, lookahead)
    return mentions


def extract_sales_opportunity_mentions(text: str) -> list[SampleMention]:
    mentions: list[SampleMention] = []
    for line in [line.strip() for line in text.splitlines() if line.strip()]:
        match = SAMPLE_MARKER_RE.search(line)
        tail = match.group("tail") if match else line
        sales_mention = sales_opportunity_mention_from_tail(clean_tail(tail))
        if sales_mention:
            mentions.append(sales_mention)
    return mentions


def sales_opportunity_mention_from_tail(raw_tail: str) -> SampleMention | None:
    match = SALES_OPPORTUNITY_WORD_RE.search(raw_tail)
    if not match:
        return None
    before = re.sub(r"['’]s\s*$", "", raw_tail[: match.start()].rstrip())
    tokens = [strip_possessive(token) for token in tokenize_tail(before)]
    tokens = [token for token in tokens if token]
    selected = select_sales_opportunity_name_tokens(tokens)
    if not selected:
        return None
    name = " ".join(selected)
    return SampleMention(raw_text=name, candidates=sample_name_candidates(name))


def strip_possessive(token: str) -> str:
    return re.sub(r"['’]s$", "", token)


def select_sales_opportunity_name_tokens(tokens: list[str]) -> list[str]:
    if not tokens:
        return []
    selected: list[str] = []
    consec_caps = 0
    for token in reversed(tokens):
        lowered = token.lower()
        is_particle = lowered in NAME_PARTICLES
        is_cap = bool(token) and (token[:1].isupper() or token.isupper())
        if not selected:
            if is_cap or (token.isalpha() and len(token) >= 2):
                selected.insert(0, token)
                consec_caps = 1 if is_cap else 0
                continue
            break
        if is_particle:
            selected.insert(0, token)
            consec_caps = 0
            continue
        if is_cap:
            if consec_caps >= 1:
                break
            selected.insert(0, token)
            consec_caps += 1
            continue
        break
    if len(selected) >= 2 and looks_like_name(selected):
        return selected
    if len(tokens) >= 2:
        fallback = tokens[-2:]
        if looks_like_name(fallback):
            return fallback
    return []


def clean_tail(value: str) -> str:
    text = re.sub(r"\s+", " ", value).strip(" -:\t")
    text = re.sub(r"^[•*\-]+\s*", "", text).strip(" -:\t")
    text = re.split(r"\s{2,}|\t", text, maxsplit=1)[0].strip(" -:")
    return text


def should_collect_more_name_parts(collected: list[str]) -> bool:
    tokens = tokenize_tail(" ".join(collected))
    if not tokens:
        return True
    if tokens[-1].lower() in NAME_PARTICLES:
        return True
    return len(tokens) < 2


def looks_like_name_fragment(value: str) -> bool:
    text = clean_tail(value)
    if not text or len(text) > 60:
        return False
    if any(word in text.casefold() for word in ["http", "www.", "tegel", "marazzi", "ragno", "workshop", "zellige"]):
        return False
    tokens = tokenize_tail(text)
    if not tokens:
        return False
    return bool(sample_name_candidates(text))


def sample_name_candidates(raw_tail: str) -> list[str]:
    tokens = tokenize_tail(raw_tail)
    if not tokens:
        return []

    candidates: list[str] = []
    max_tokens = min(len(tokens), 6)
    for size in range(2, max_tokens + 1):
        selected = tokens[:size]
        if looks_like_name(selected):
            candidates.append(" ".join(selected))

    if len(tokens) == 1 and looks_like_name(tokens):
        candidates.append(tokens[0])

    # Prefer shorter names first; the Odoo resolver will try all candidates
    # exactly and use the one that exists in crm.lead.
    return unique_preserve_order(candidates)


def tokenize_tail(raw_tail: str) -> list[str]:
    tokens: list[str] = []
    for token in re.findall(r"[A-Za-zÀ-ÖØ-öø-ÿ'`.-]+", raw_tail):
        cleaned = token.strip(" .,'`-")
        if not cleaned:
            continue
        lowered = cleaned.lower()
        if lowered in STOP_WORDS or re.search(r"\d", cleaned):
            break
        tokens.append(cleaned)
    return tokens


def looks_like_name(tokens: list[str]) -> bool:
    if not tokens:
        return False
    if tokens[-1].lower() in NAME_PARTICLES:
        return False
    strong_name_parts = 0
    for token in tokens:
        lowered = token.lower()
        if lowered in NAME_PARTICLES:
            continue
        if lowered in STOP_WORDS:
            return False
        if token[:1].isupper() or token.isupper():
            strong_name_parts += 1
            continue
        if token.isalpha() and len(token) >= 2:
            strong_name_parts += 1
            continue
        return False
    return strong_name_parts >= 1


def dedupe_mentions(mentions: list[SampleMention]) -> list[SampleMention]:
    result: list[SampleMention] = []
    seen: set[str] = set()
    for mention in mentions:
        key = mention.best_name.casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(mention)
    return result


def unique_preserve_order(values: list[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = re.sub(r"\s+", " ", value).strip()
        key = normalized.casefold()
        if normalized and key not in seen:
            seen.add(key)
            result.append(normalized)
    return result
