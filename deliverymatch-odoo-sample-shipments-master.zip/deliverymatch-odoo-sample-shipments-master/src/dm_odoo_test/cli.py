from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
from typing import Any

from .deliverymatch_client import DeliveryMatchClient, config_from_env_or_prompt
from .env import load_dotenv
from .ocr import OCRError, image_to_text
from .odoo_client import OdooClient, OdooError, SampleLeadResolver, config_from_env_or_prompt as odoo_config_from_env_or_prompt
from .payload_builder import (
    MappingError,
    build_insert_shipment_payload,
    load_json,
    save_json,
    should_send_to_deliverymatch,
    validate_payload,
)
from .sample_parser import SampleMention, extract_sample_mentions
from .sample_payload import (
    SamplePayloadError,
    build_sample_shipment_payload,
    sample_order_number,
    validate_sample_payload,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Odoo CRM sample-aanvragen naar DeliveryMatch shipments.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    build = subparsers.add_parser("build-payload", help="Maak een DeliveryMatch insertShipment payload uit mock Odoo JSON.")
    build.add_argument("--odoo-json", default="data/odoo_order_ord18026.json")
    build.add_argument("--client-id", default="101276")
    build.add_argument("--out", default="outputs/ord18026_insert_payload.json")
    build.add_argument("--order-number", help="Override shipment.orderNumber, useful for a unique live test.")
    build.add_argument("--reference", help="Override shipment.reference.")
    build.add_argument("--print-json", action="store_true")

    validate = subparsers.add_parser("validate-payload", help="Controleer of een payload lokaal compleet lijkt.")
    validate.add_argument("--payload", required=True)

    simulate = subparsers.add_parser("simulate-trigger", help="Simuleer: magazijn kiest DHL op WH/OUT en Odoo bouwt payload.")
    simulate.add_argument("--odoo-json", default="data/odoo_order_ord18026.json")
    simulate.add_argument("--client-id", default="101276")
    simulate.add_argument("--out", default="outputs/simulated_trigger_payload.json")
    simulate.add_argument("--order-number", help="Override shipment.orderNumber, useful for a unique live test.")
    simulate.add_argument("--reference", help="Override shipment.reference.")

    me = subparsers.add_parser("me", help="Read-only DeliveryMatch auth smoke test.")
    add_api_args(me)

    insert = subparsers.add_parser("insert-shipment", help="Roep DeliveryMatch /insertShipment aan. Guarded write.")
    add_api_args(insert)
    insert.add_argument("--payload", required=True)
    insert.add_argument("--execute-write", action="store_true")
    insert.add_argument("--out", default="")

    extract = subparsers.add_parser("extract-samples", help="Lees sample-aanvraag namen uit OCR tekst of een PNG/JPG.")
    add_ocr_args(extract)
    extract.add_argument("--print-ocr", action="store_true")

    sample = subparsers.add_parser(
        "create-sample-shipments",
        help="Lees een samplelijst, zoek exacte CRM leads in Odoo en maak DeliveryMatch sample shipments.",
    )
    add_ocr_args(sample)
    add_api_args(sample)
    sample.add_argument("--only", help="Verwerk alleen deze exacte sample naam, bijvoorbeeld 'Iris Siemerink'.")
    sample.add_argument("--reference", default="sample")
    sample.add_argument("--pickup-date", help="YYYY-MM-DD. Default is vandaag.")
    sample.add_argument("--execute-write", action="store_true")
    sample.add_argument("--force", action="store_true", help="Negeer lokale duplicate-log en DeliveryMatch duplicate-check; maak altijd een nieuwe shipment aan.")
    sample.add_argument("--bypass-all-checks", action="store_true", help="Forceer DM shipment ongeacht stage, lokale log of DM-duplicate. Bij DM 409 wordt automatisch een RETRY-suffix toegevoegd zodat de shipment alsnog wordt aangemaakt.")
    sample.add_argument("--print-payloads", action="store_true")
    sample.add_argument("--processed-stage-name", default=os.environ.get("ODOO_PROCESSED_STAGE_NAME", "Verzonden/meegegeven"))
    sample.add_argument("--skip-odoo-stage-update", action="store_true")
    sample.add_argument("--out", default="outputs/sample_shipments_run.json")

    return parser.parse_args()


def add_api_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--env", choices=["prod", "test"], default="prod")
    parser.add_argument("--client-id")
    parser.add_argument("--api-key")
    parser.add_argument("--timeout", type=float, default=30.0)


def add_ocr_args(parser: argparse.ArgumentParser) -> None:
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--image", action="append", help="PNG/JPG met sample-aanvraag tabel. Mag meerdere keren.")
    source.add_argument("--ocr-text", help="Tekstbestand met eerder gemaakte OCR-output.")
    parser.add_argument("--ocr-backend", choices=["auto", "rapidocr", "windows", "tesseract"], default="auto")
    parser.add_argument("--ocr-language", default="nl-NL")
    parser.add_argument("--no-auto-rotate", action="store_true")


def main() -> int:
    load_dotenv()
    args = parse_args()
    try:
        if args.command == "build-payload":
            return command_build_payload(args)
        if args.command == "validate-payload":
            return command_validate_payload(args)
        if args.command == "simulate-trigger":
            return command_simulate_trigger(args)
        if args.command == "me":
            return command_me(args)
        if args.command == "insert-shipment":
            return command_insert_shipment(args)
        if args.command == "extract-samples":
            return command_extract_samples(args)
        if args.command == "create-sample-shipments":
            return command_create_sample_shipments(args)
    except MappingError as exc:
        print(f"Mapping fout: {exc}")
        return 2
    except (OCRError, OdooError, SamplePayloadError) as exc:
        print(f"Fout: {exc}")
        return 2
    raise SystemExit(f"Onbekend commando: {args.command}")


def command_build_payload(args: argparse.Namespace) -> int:
    odoo_order = load_json(args.odoo_json)
    payload = build_insert_shipment_payload(odoo_order, str(args.client_id))
    apply_identifier_overrides(payload, args.order_number, args.reference)
    errors = validate_payload(payload)
    if errors:
        for error in errors:
            print(f"- {error}")
        return 2
    target = save_json(args.out, payload)
    print(f"Payload geschreven: {target}")
    if args.print_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


def command_validate_payload(args: argparse.Namespace) -> int:
    payload = load_json(args.payload)
    errors = validate_payload(payload)
    if errors:
        print("Payload is nog niet geldig:")
        for error in errors:
            print(f"- {error}")
        return 2
    print("Payload lijkt lokaal compleet.")
    return 0


def command_simulate_trigger(args: argparse.Namespace) -> int:
    odoo_order = load_json(args.odoo_json)
    picking = odoo_order.get("stock_picking") or {}
    if not should_send_to_deliverymatch(odoo_order):
        print(f"Skip: vervoerder is {picking.get('carrier_name') or picking.get('carrier_code')}, niet DHL.")
        return 0
    if (picking.get("deliverymatch") or {}).get("shipment_id"):
        print("Skip: levering heeft al een DeliveryMatch shipment_id.")
        return 0

    payload = build_insert_shipment_payload(odoo_order, str(args.client_id))
    apply_identifier_overrides(payload, args.order_number, args.reference)
    errors = validate_payload(payload)
    if errors:
        print("Trigger geblokkeerd door lokale validatie:")
        for error in errors:
            print(f"- {error}")
        return 2
    target = save_json(args.out, payload)
    print(f"Trigger OK: DHL gekozen op {picking.get('name')}; payload staat in {target}")
    return 0


def command_me(args: argparse.Namespace) -> int:
    client = DeliveryMatchClient(config_from_env_or_prompt(args.env, args.client_id, args.api_key, args.timeout))
    response = client.me()
    print(json.dumps(safe_response(response), ensure_ascii=False, indent=2))
    return 0 if response.get("ok") else 1


def command_insert_shipment(args: argparse.Namespace) -> int:
    if not args.execute_write:
        print("Schrijven is geblokkeerd. Voeg bewust --execute-write toe voor /insertShipment.")
        return 2

    payload = load_json(args.payload)
    errors = validate_payload(payload)
    if errors:
        print("Payload is niet verzonden door lokale validatiefouten:")
        for error in errors:
            print(f"- {error}")
        return 2

    client = DeliveryMatchClient(config_from_env_or_prompt(args.env, args.client_id, args.api_key, args.timeout))
    response = client.insert_shipment(payload)
    safe = safe_response(response)
    print(json.dumps(safe, ensure_ascii=False, indent=2))
    if args.out:
        save_json(args.out, {"called_at": dt.datetime.now().isoformat(timespec="seconds"), "response": response})
    return 0 if response.get("ok") else 1


def command_extract_samples(args: argparse.Namespace) -> int:
    text = read_sample_source_text(args)
    mentions = extract_sample_mentions(text)
    if args.print_ocr:
        print("OCR tekst:")
        print(text.rstrip())
        print("")
    if not mentions:
        print("Geen sample-aanvragen gevonden.")
        return 1
    for index, mention in enumerate(mentions, start=1):
        alternatives = ", ".join(mention.candidates[1:])
        suffix = f" (alternatieven: {alternatives})" if alternatives else ""
        print(f"{index}. {mention.best_name}{suffix}")
    return 0


def command_create_sample_shipments(args: argparse.Namespace) -> int:
    text = read_sample_source_text(args)
    mentions = filter_mentions(extract_sample_mentions(text), args.only)
    if not mentions:
        target = f" voor '{args.only}'" if args.only else ""
        print(f"Geen sample-aanvragen{target} gevonden in OCR tekst.")
        return 1

    pickup_date = parse_optional_date(args.pickup_date)
    odoo_client = OdooClient(odoo_config_from_env_or_prompt())
    resolver = SampleLeadResolver(odoo_client)
    dm_client = None
    dm_client_id = selected_deliverymatch_client_id(args)
    if args.execute_write or args.api_key or os.environ.get("DELIVERYMATCH_API_KEY"):
        dm_client = DeliveryMatchClient(config_from_env_or_prompt(args.env, args.client_id, args.api_key, args.timeout))
        dm_client_id = dm_client.config.client_id

    duplicate_log = load_duplicate_log()
    run: dict[str, Any] = {
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        "execute_write": bool(args.execute_write),
        "source": args.image or args.ocr_text,
        "only": args.only or "",
        "results": [],
    }

    for mention in mentions:
        result = process_sample_mention(
            mention,
            resolver=resolver,
            dm_client=dm_client,
            dm_client_id=dm_client_id,
            pickup_date=pickup_date,
            reference=args.reference,
            execute_write=args.execute_write,
            force=args.force or args.bypass_all_checks,
            bypass_all_checks=args.bypass_all_checks,
            duplicate_log=duplicate_log,
            print_payload=args.print_payloads,
            processed_stage_name=None if args.skip_odoo_stage_update else args.processed_stage_name,
        )
        run["results"].append(result)
        print_sample_result(result)

    if args.execute_write:
        save_duplicate_log(duplicate_log)
    if args.out:
        save_json(args.out, run)
        print(f"Runrapport geschreven: {args.out}")

    failures = [result for result in run["results"] if result.get("status") in {"error", "failed"} or str(result.get("status", "")).endswith("_failed")]
    if failures:
        print(f"Runrapport bevat {len(failures)} fout(en).")
        if args.execute_write:
            return 1
    return 0


def process_sample_mention(
    mention: SampleMention,
    *,
    resolver: SampleLeadResolver,
    dm_client: DeliveryMatchClient | None,
    dm_client_id: str,
    pickup_date: dt.date | None,
    reference: str,
    execute_write: bool,
    force: bool,
    duplicate_log: dict[str, Any],
    print_payload: bool,
    processed_stage_name: str | None,
    bypass_all_checks: bool = False,
) -> dict[str, Any]:
    lead = None
    try:
        lead = resolver.resolve(mention.candidates)
        order_number = sample_order_number(lead.id, lead.sample_name)
        payload = build_sample_shipment_payload(
            lead.receiver,
            client_id=dm_client_id,
            order_number=order_number,
            reference=reference,
            pickup_date=pickup_date,
        )
        errors = validate_sample_payload(payload)
        if errors:
            raise SamplePayloadError("; ".join(errors))

        result: dict[str, Any] = {
            "status": "dry-run",
            "sample_name": lead.sample_name,
            "candidate_names": mention.candidates,
            "odoo_lead_id": lead.id,
            "odoo_lead_name": lead.lead_name,
            "odoo_stage": lead.stage_name,
            "orderNumber": order_number,
            "reference": reference,
            "receiver": safe_receiver_summary(lead.receiver),
        }
        if print_payload:
            result["payload"] = payload

        required_stage = os.environ.get("SAMPLE_REQUIRED_STAGE", "Te versturen/binnen")
        if execute_write and not bypass_all_checks and lead.stage_name != required_stage:
            result["status"] = "skipped_stage"
            result["reason"] = (
                f"CRM stage is '{lead.stage_name or 'onbekend'}', alleen '{required_stage}' wordt verwerkt."
            )
            return result

        lead_key = str(lead.id)
        if not force and duplicate_log.get(lead_key, {}).get("ok"):
            result["status"] = "skipped_duplicate"
            result["reason"] = f"CRM lead {lead.id} staat al als verzonden in outputs/sample_shipments_log.json."
            return mark_processed_stage_if_needed(result, resolver, lead, execute_write, processed_stage_name)

        if dm_client is not None and not force:
            duplicate = find_deliverymatch_duplicate(dm_client, order_number)
            if duplicate:
                result["status"] = "skipped_duplicate"
                result["reason"] = "DeliveryMatch bevat al een shipment voor dit sample orderNumber."
                result["deliverymatch_existing"] = duplicate
                duplicate_log[lead_key] = {
                    "sample_name": lead.sample_name,
                    "odoo_lead_name": lead.lead_name,
                    "orderNumber": order_number,
                    "shipmentID": duplicate.get("shipmentID"),
                    "detected_at": dt.datetime.now().isoformat(timespec="seconds"),
                    "ok": True,
                    "source": "deliverymatch_duplicate_check",
                }
                return mark_processed_stage_if_needed(result, resolver, lead, execute_write, processed_stage_name)
            result["duplicate_check"] = "not_found"
        elif force:
            result["duplicate_check"] = "skipped_force"
        elif not execute_write:
            result["duplicate_check"] = "not_run_no_deliverymatch_api_key"

        if not execute_write:
            return result

        if dm_client is None:
            raise SamplePayloadError("DeliveryMatch client ontbreekt.")

        response = dm_client.insert_shipment(payload)
        if (
            bypass_all_checks
            and not response.get("ok")
            and is_duplicate_order_number_response(response)
        ):
            retry_order_number = f"{order_number}-RETRY-{dt.datetime.now().strftime('%Y%m%d-%H%M%S')}"
            payload["shipment"]["orderNumber"] = retry_order_number
            order_number = retry_order_number
            result["orderNumber"] = retry_order_number
            result["bypass_retry_with_suffix"] = True
            response = dm_client.insert_shipment(payload)
        safe = safe_response(response)
        result["deliverymatch"] = safe
        if response.get("ok"):
            result["status"] = "sent"
            duplicate_log[lead_key] = {
                "sample_name": lead.sample_name,
                "odoo_lead_name": lead.lead_name,
                "orderNumber": order_number,
                "shipmentID": safe.get("shipmentID"),
                "sent_at": dt.datetime.now().isoformat(timespec="seconds"),
                "ok": True,
            }
            result = mark_processed_stage_if_needed(result, resolver, lead, execute_write, processed_stage_name)
        else:
            result["status"] = "failed"
        return result
    except OdooError as exc:
        return {
            "status": "error",
            "raw_text": mention.raw_text,
            "candidate_names": mention.candidates,
            "error": str(exc),
        }
    except SamplePayloadError as exc:
        result = {
            "status": "error",
            "raw_text": mention.raw_text,
            "candidate_names": mention.candidates,
            "error": str(exc),
        }
        if lead is not None:
            result.update(
                {
                    "sample_name": lead.sample_name,
                    "odoo_lead_id": lead.id,
                    "odoo_lead_name": lead.lead_name,
                    "receiver": safe_receiver_summary(lead.receiver),
                }
            )
        return result


def mark_processed_stage_if_needed(
    result: dict[str, Any],
    resolver: SampleLeadResolver,
    lead: Any,
    execute_write: bool,
    processed_stage_name: str | None,
) -> dict[str, Any]:
    if not execute_write or not processed_stage_name:
        return result
    try:
        result["odoo_stage_update"] = resolver.move_to_stage(lead.id, processed_stage_name)
        return result
    except OdooError as exc:
        result["odoo_stage_update"] = {
            "ok": False,
            "target_stage": processed_stage_name,
            "error": str(exc),
        }
        result["status"] = f"{result.get('status')}_stage_update_failed"
        return result


def find_deliverymatch_duplicate(dm_client: DeliveryMatchClient, order_number: str) -> dict[str, Any] | None:
    response = dm_client.get_shipment_by_order_number(order_number)
    if response.get("ok"):
        safe = safe_response(response)
        if safe.get("shipmentID") or safe.get("orderNumber"):
            return safe
        data = response.get("json")
        if contains_shipment_data(data):
            return safe or {"status_code": response.get("status_code"), "match": True}
        return None

    if shipment_not_found_response(response):
        return None

    raise SamplePayloadError(f"DeliveryMatch duplicate-check mislukt voor {order_number}: {safe_response(response)}")


def is_duplicate_order_number_response(response: dict[str, Any]) -> bool:
    if response.get("status_code") != 409:
        return False
    data = response.get("json") or {}
    blob = " ".join(
        str(data.get(key) or "") for key in ("message", "status", "error", "errors")
    ).casefold()
    return "already exists" in blob or "bestaat al" in blob or "order number" in blob


def shipment_not_found_response(response: dict[str, Any]) -> bool:
    status_code = response.get("status_code")
    data = response.get("json")
    message = ""
    if isinstance(data, dict):
        message = " ".join(str(data.get(key) or "") for key in ("message", "status", "error", "errors")).casefold()
    raw = str(response.get("raw") or response.get("error") or "").casefold()
    text = f"{message} {raw}"
    if status_code == 404:
        return True
    if status_code in {200, 204} and not contains_shipment_data(data):
        return True
    return any(needle in text for needle in ("not found", "niet gevonden", "no shipment", "geen shipment", "unknown shipment"))


def contains_shipment_data(value: Any) -> bool:
    if isinstance(value, dict):
        shipment = value.get("shipment")
        if isinstance(shipment, dict) and any(shipment.get(key) for key in ("id", "orderNumber", "reference")):
            return True
        if any(value.get(key) for key in ("shipmentID", "shipmentId", "id", "orderNumber")):
            return True
        return any(contains_shipment_data(child) for child in value.values())
    if isinstance(value, list):
        return any(contains_shipment_data(child) for child in value)
    return False


def safe_response(response: dict[str, Any]) -> dict[str, Any]:
    data = response.get("json")
    if not isinstance(data, dict):
        return response

    summary: dict[str, Any] = {
        "ok": response.get("ok"),
        "status_code": response.get("status_code"),
        "message": data.get("message"),
        "status": data.get("status"),
        "shipmentID": data.get("shipmentID") or data.get("shipmentId") or data.get("id") or ((data.get("shipment") or {}).get("id") if isinstance(data.get("shipment"), dict) else None),
        "orderNumber": (data.get("shipment") or {}).get("orderNumber") if isinstance(data.get("shipment"), dict) else data.get("orderNumber"),
        "barcodes": len(data.get("barcodes") or []),
        "codeShipments": len(data.get("codeShipments") or []),
        "errors": data.get("error") or data.get("errors")
    }
    return {key: value for key, value in summary.items() if value not in (None, "", [])}


def apply_identifier_overrides(payload: dict[str, Any], order_number: str | None, reference: str | None) -> None:
    shipment = payload.setdefault("shipment", {})
    if order_number:
        shipment["orderNumber"] = order_number
    if reference:
        shipment["reference"] = reference


def read_sample_source_text(args: argparse.Namespace) -> str:
    if args.ocr_text:
        return Path(args.ocr_text).read_text(encoding="utf-8")
    parts: list[str] = []
    for image_path in args.image or []:
        parts.append(
            image_to_text(
                image_path,
                backend=args.ocr_backend,
                language=args.ocr_language,
                auto_rotate=not args.no_auto_rotate,
            )
        )
    return "\n".join(parts)


def filter_mentions(mentions: list[SampleMention], only: str | None) -> list[SampleMention]:
    if not only:
        return mentions
    target = only.strip().casefold()
    return [mention for mention in mentions if any(candidate.casefold() == target for candidate in mention.candidates)]


def selected_deliverymatch_client_id(args: argparse.Namespace) -> str:
    return str(args.client_id or os.environ.get("DELIVERYMATCH_CLIENT_ID") or "101276")


def parse_optional_date(value: str | None) -> dt.date | None:
    if not value:
        return None
    return dt.datetime.strptime(value, "%Y-%m-%d").date()


def load_duplicate_log(path: str | Path = "outputs/sample_shipments_log.json") -> dict[str, Any]:
    target = Path(path)
    if not target.exists():
        return {}
    data = load_json(target)
    return data if isinstance(data, dict) else {}


def save_duplicate_log(data: dict[str, Any], path: str | Path = "outputs/sample_shipments_log.json") -> None:
    save_json(path, data)


def safe_receiver_summary(receiver: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": receiver.get("name"),
        "company_name": receiver.get("company_name"),
        "street": receiver.get("street"),
        "house_number": receiver.get("house_number"),
        "postcode": receiver.get("postcode"),
        "city": receiver.get("city"),
        "country": receiver.get("country"),
        "email_present": bool(receiver.get("email")),
        "phone_present": bool(receiver.get("phone")),
    }


def print_sample_result(result: dict[str, Any]) -> None:
    status = result.get("status")
    name = result.get("sample_name") or ", ".join(result.get("candidate_names") or [])
    if status == "dry-run":
        print(f"DRY-RUN {name}: Odoo lead {result.get('odoo_lead_id')} -> {result.get('orderNumber')}")
    elif status == "sent":
        dm = result.get("deliverymatch") or {}
        print(f"VERZONDEN {name}: shipmentID={dm.get('shipmentID', '?')} order={result.get('orderNumber')}")
    elif status in {"skipped", "skipped_duplicate", "skipped_stage"}:
        print(f"OVERGESLAGEN {name}: {result.get('reason')}")
    else:
        print(f"FOUT {name}: {result.get('error') or result.get('deliverymatch')}")


if __name__ == "__main__":
    raise SystemExit(main())
