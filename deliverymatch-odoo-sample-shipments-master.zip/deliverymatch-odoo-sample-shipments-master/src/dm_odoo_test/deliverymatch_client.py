from __future__ import annotations

import getpass
import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any


BASE_URLS = {
    "prod": "https://engine.deliverymatch.eu/api/v1",
    "test": "https://engine-test.deliverymatch.eu/api/v1",
}


@dataclass(frozen=True)
class DeliveryMatchConfig:
    client_id: str
    api_key: str
    base_url: str
    timeout: float = 30.0


class DeliveryMatchClient:
    def __init__(self, config: DeliveryMatchConfig) -> None:
        self.config = config

    def post(self, endpoint: str, body: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.config.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        request = urllib.request.Request(
            url,
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            method="POST",
            headers={
                "accept": "application/json",
                "content-type": "application/json",
                "client": self.config.client_id,
                "apikey": self.config.api_key,
                "user-agent": "deliverymatch-odoo-test/0.1"
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=self.config.timeout) as response:
                raw = response.read().decode("utf-8", errors="replace")
                return parse_response(response.status, dict(response.headers), raw)
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            return parse_response(exc.code, dict(exc.headers), raw)
        except urllib.error.URLError as exc:
            return {
                "ok": False,
                "status_code": None,
                "headers": {},
                "json": None,
                "raw": "",
                "error": str(exc.reason)
            }

    def me(self) -> dict[str, Any]:
        return self.post("/me", {})

    def insert_shipment(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.post("/insertShipment", payload)

    def get_shipment_by_order_number(self, order_number: str) -> dict[str, Any]:
        return self.post("/getShipment", {"shipment": {"orderNumber": order_number}})


def config_from_env_or_prompt(env: str, client_id: str | None, api_key: str | None, timeout: float) -> DeliveryMatchConfig:
    selected_env = env or os.environ.get("DELIVERYMATCH_ENV", "prod")
    selected_client_id = client_id or os.environ.get("DELIVERYMATCH_CLIENT_ID")
    if not selected_client_id:
        selected_client_id = input("DeliveryMatch Webshop ID / clientnummer: ").strip()
    if not selected_client_id:
        raise SystemExit("DeliveryMatch client id ontbreekt.")

    selected_api_key = api_key or os.environ.get("DELIVERYMATCH_API_KEY")
    if not selected_api_key:
        selected_api_key = getpass.getpass("DeliveryMatch API key (verborgen): ").strip()
    if not selected_api_key:
        raise SystemExit("DeliveryMatch API key ontbreekt.")

    base_url = os.environ.get("DELIVERYMATCH_BASE_URL") or BASE_URLS[selected_env]
    return DeliveryMatchConfig(
        client_id=str(selected_client_id),
        api_key=selected_api_key,
        base_url=base_url,
        timeout=timeout
    )


def parse_response(status_code: int, headers: dict[str, str], raw: str) -> dict[str, Any]:
    parsed: Any = None
    parse_error = None
    if raw:
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError as exc:
            parse_error = str(exc)
    return {
        "ok": 200 <= status_code < 300,
        "status_code": status_code,
        "headers": {
            "content-type": headers.get("Content-Type") or headers.get("content-type"),
            "date": headers.get("Date") or headers.get("date")
        },
        "json": parsed,
        "raw": None if parsed is not None else raw,
        "parse_error": parse_error
    }
