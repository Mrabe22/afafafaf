from __future__ import annotations

import datetime as dt
import json
import re
from pathlib import Path
from typing import Any


DHL_CODES = {"DHL", "DHLPARCEL", "DHL PARCEL", "DHL_PARCEL"}


class MappingError(ValueError):
    """Raised when the Odoo fixture cannot safely become a DeliveryMatch shipment."""


def load_json(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise MappingError(f"Expected JSON object in {path}.")
    return data


def save_json(path: str | Path, data: dict[str, Any]) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    return target


def should_send_to_deliverymatch(odoo_order: dict[str, Any]) -> bool:
    picking = odoo_order.get("stock_picking") or {}
    carrier = str(picking.get("carrier_code") or picking.get("carrier_name") or "").upper()
    return carrier in DHL_CODES


def build_insert_shipment_payload(odoo_order: dict[str, Any], client_id: str) -> dict[str, Any]:
    if not client_id:
        raise MappingError("DeliveryMatch client id ontbreekt.")
    if not should_send_to_deliverymatch(odoo_order):
        raise MappingError("Deze levering heeft geen DHL-vervoerder en wordt niet naar DeliveryMatch gestuurd.")

    sale_order = required_dict(odoo_order, "sale_order")
    picking = required_dict(odoo_order, "stock_picking")
    sender = required_dict(odoo_order, "sender")
    customer = required_dict(sale_order, "customer")
    defaults = odoo_order.get("deliverymatch_defaults") or {}

    existing_shipment_id = ((picking.get("deliverymatch") or {}).get("shipment_id"))
    if existing_shipment_id:
        raise MappingError(f"Levering heeft al DeliveryMatch shipment_id={existing_shipment_id}.")

    product_lines = [line for line in sale_order.get("lines") or [] if is_deliverymatch_product_line(line)]
    if not product_lines:
        raise MappingError("Geen productregels gevonden voor DeliveryMatch quote.product[].")

    packages = build_packages(picking, product_lines)
    products = build_products(product_lines, packages)
    delivery_date = parse_date(picking.get("scheduled_date") or sale_order.get("scheduled_delivery"))

    total_weight = round(sum(float(package.get("weight") or 0) for package in packages), 3)
    product_value = round(sum(float(product.get("value") or 0) for product in products), 2)

    return {
        "client": {
            "id": int(client_id) if str(client_id).isdigit() else str(client_id),
            "action": "save",
            "method": "lowprice",
            "filter": False,
            "transportlabel": False,
            "copy": False
        },
        "sender": {
            "address": build_address(sender, sender=True),
            "contact": build_contact(sender)
        },
        "customer": {
            "address": build_address(customer, sender=False),
            "contact": build_contact(customer)
        },
        "shipment": {
            "status": "new",
            "orderNumber": first_text(sale_order.get("reference"), picking.get("name"), sale_order.get("name")),
            "reference": first_text(sale_order.get("name"), picking.get("origin"), sale_order.get("reference")),
            "language": defaults.get("language") or "nl",
            "currency": sale_order.get("currency") or "EUR",
            "deliveryDate": delivery_date.isoformat(),
            "deliveryTimeFrom": defaults.get("delivery_time_from") or "09:00",
            "deliveryTimeTo": defaults.get("delivery_time_to") or "17:00",
            "inbound": False
        },
        "carrier": {
            "name": defaults.get("carrier_name") or "DHLPARCEL"
        },
        "serviceLevel": {
            "name": defaults.get("service_level") or "product[DFY]options[DOOR]"
        },
        "packages": {
            "package": packages
        },
        "quote": {
            "product": products
        },
        "fragileGoods": False,
        "dangerousGoods": False,
        "colli": len(packages),
        "priceIncl": round(float(sale_order.get("amount_total") or product_value), 2),
        "priceExcl": product_value,
        "weight": total_weight
    }


def validate_payload(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    required_paths = [
        "client.id",
        "sender.address.address1",
        "sender.address.postcode",
        "sender.address.city",
        "sender.address.country",
        "customer.address.name",
        "customer.address.address1",
        "customer.address.postcode",
        "customer.address.city",
        "customer.address.country",
        "shipment.orderNumber",
        "shipment.reference",
        "packages.package",
        "quote.product",
    ]
    for path in required_paths:
        value = deep_get(payload, path)
        if value in (None, "", []):
            errors.append(f"Ontbrekend verplicht veld: {path}")

    package_list = deep_get(payload, "packages.package") or []
    if not isinstance(package_list, list) or not package_list:
        errors.append("packages.package moet minimaal 1 pakket bevatten.")

    product_list = deep_get(payload, "quote.product") or []
    if not isinstance(product_list, list) or not product_list:
        errors.append("quote.product moet minimaal 1 productregel bevatten.")

    if contains_placeholder(payload):
        errors.append("Payload bevat nog REPLACE/TEST placeholders.")

    postcode = str(deep_get(payload, "sender.address.postcode") or "")
    if normalize_country(deep_get(payload, "sender.address.country")) == "NL" and not re.match(r"^[1-9]\d{3}\s?[A-Z]{2}$", postcode):
        errors.append("Afzenderpostcode lijkt geen geldige Nederlandse postcode.")

    return errors


def build_address(data: dict[str, Any], *, sender: bool) -> dict[str, Any]:
    street = first_text(data.get("street"), data.get("address1"))
    house_number = str(data.get("house_number") or data.get("houseNr") or "").strip()
    house_ext = str(data.get("house_number_ext") or data.get("houseNrExt") or "").strip()
    address1 = " ".join(part for part in [street, house_number, house_ext] if part).strip()
    if not address1:
        raise MappingError("Adresregel ontbreekt.")

    address: dict[str, Any] = {
        "address1": address1,
        "street": street,
        "houseNr": house_number,
        "houseNrExt": house_ext,
        "postcode": normalize_postcode(data.get("postcode")),
        "city": first_text(data.get("city")),
        "country": normalize_country(data.get("country"))
    }
    if sender:
        address["companyName"] = first_text(data.get("company_name"), data.get("companyName"), data.get("name"))
        address["name"] = first_text(data.get("name"), data.get("company_name"), data.get("companyName"))
    else:
        address["name"] = first_text(data.get("name"), data.get("company_name"), data.get("companyName"))
    return address


def build_contact(data: dict[str, Any]) -> dict[str, Any]:
    return {
        "phoneNumber": empty_to_none(data.get("phone") or data.get("phoneNumber")),
        "email": empty_to_none(data.get("email"))
    }


def build_packages(picking: dict[str, Any], product_lines: list[dict[str, Any]]) -> list[dict[str, Any]]:
    raw_packages = picking.get("packages") or []
    if not raw_packages:
        raw_packages = [{
            "package_num": 1,
            "weight_kg": sum(float(line.get("weight_kg") or 0) for line in product_lines) or 1,
            "length_cm": first_number(product_lines, "length_cm", fallback=10),
            "width_cm": first_number(product_lines, "width_cm", fallback=10),
            "height_cm": first_number(product_lines, "height_cm", fallback=10),
            "description": product_lines[0].get("description") or product_lines[0].get("product_name")
        }]

    packages: list[dict[str, Any]] = []
    for index, package in enumerate(raw_packages, start=1):
        packages.append({
            "weight": positive_float(package.get("weight_kg"), "package.weight_kg"),
            "width": positive_float(package.get("width_cm"), "package.width_cm"),
            "length": positive_float(package.get("length_cm"), "package.length_cm"),
            "height": positive_float(package.get("height_cm"), "package.height_cm"),
            "packageNum": int(package.get("package_num") or index),
            "description": first_text(package.get("description"), product_lines[0].get("description"))
        })
    return packages


def build_products(product_lines: list[dict[str, Any]], packages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    products: list[dict[str, Any]] = []
    fallback_package = packages[0]
    for line in product_lines:
        products.append({
            "SKU": empty_to_none(line.get("product_code")),
            "quantity": positive_float(line.get("quantity"), "line.quantity"),
            "value": round(float(line.get("subtotal") or 0), 2),
            "weight": positive_float(line.get("weight_kg") or fallback_package.get("weight"), "line.weight_kg"),
            "length": positive_float(line.get("length_cm") or fallback_package.get("length"), "line.length_cm"),
            "width": positive_float(line.get("width_cm") or fallback_package.get("width"), "line.width_cm"),
            "height": positive_float(line.get("height_cm") or fallback_package.get("height"), "line.height_cm"),
            "description": first_text(line.get("description"), line.get("product_name")),
            "packageNum": 1
        })
    return products


def is_deliverymatch_product_line(line: dict[str, Any]) -> bool:
    if line.get("is_delivery_charge"):
        return False
    code = str(line.get("product_code") or "").strip().lower()
    name = str(line.get("product_name") or "").strip().lower()
    return code != "shipment" and name != "shipment"


def required_dict(data: dict[str, Any], key: str) -> dict[str, Any]:
    value = data.get(key)
    if not isinstance(value, dict):
        raise MappingError(f"Ontbrekend object: {key}")
    return value


def deep_get(data: dict[str, Any], dotted_path: str) -> Any:
    current: Any = data
    for part in dotted_path.split("."):
        if not isinstance(current, dict):
            return None
        current = current.get(part)
    return current


def contains_placeholder(value: Any) -> bool:
    if isinstance(value, dict):
        return any(contains_placeholder(child) for child in value.values())
    if isinstance(value, list):
        return any(contains_placeholder(child) for child in value)
    if isinstance(value, str):
        upper = value.upper()
        return "REPLACE" in upper or "TEST-REPLACE" in upper
    return False


def first_text(*values: Any) -> str:
    for value in values:
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def empty_to_none(value: Any) -> Any:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def normalize_country(value: Any) -> str:
    text = first_text(value).upper()
    mapping = {
        "NEDERLAND": "NL",
        "NETHERLANDS": "NL",
        "THE NETHERLANDS": "NL",
        "NL": "NL",
        "DUITSLAND": "DE",
        "GERMANY": "DE",
        "DEUTSCHLAND": "DE",
        "DE": "DE"
    }
    return mapping.get(text, text)


def normalize_postcode(value: Any) -> str:
    return first_text(value).replace(" ", "").upper()


def parse_date(value: Any) -> dt.date:
    if not value:
        return dt.date.today()
    text = str(value).strip()
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(text[:19] if "T" in text else text, fmt).date()
        except ValueError:
            continue
    raise MappingError(f"Datumformaat niet herkend: {text}")


def positive_float(value: Any, field_name: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise MappingError(f"{field_name} moet numeriek zijn.") from exc
    if number <= 0:
        raise MappingError(f"{field_name} moet groter zijn dan 0.")
    return round(number, 3)


def first_number(rows: list[dict[str, Any]], key: str, *, fallback: float) -> float:
    for row in rows:
        if row.get(key):
            return float(row[key])
    return fallback

