from __future__ import annotations

import getpass
import os
import re
import xmlrpc.client
from dataclasses import dataclass
from typing import Any


class OdooError(RuntimeError):
    """Raised when Odoo cannot resolve a sample CRM lead safely."""


@dataclass(frozen=True)
class OdooConfig:
    url: str
    db: str
    user: str
    api_key: str


class OdooClient:
    def __init__(self, config: OdooConfig) -> None:
        self.config = config
        self.uid: int | None = None
        self.models: Any = None

    def connect(self) -> None:
        common = xmlrpc.client.ServerProxy(f"{self.config.url.rstrip('/')}/xmlrpc/2/common")
        uid = common.authenticate(self.config.db, self.config.user, self.config.api_key, {})
        if not uid:
            raise OdooError("Odoo authenticatie mislukt. Controleer ODOO_URL/ODOO_DB/ODOO_USER/ODOO_API_KEY.")
        self.uid = int(uid)
        self.models = xmlrpc.client.ServerProxy(f"{self.config.url.rstrip('/')}/xmlrpc/2/object")

    def execute_kw(self, model: str, method: str, args: list[Any], kwargs: dict[str, Any] | None = None) -> Any:
        if self.uid is None or self.models is None:
            self.connect()
        return self.models.execute_kw(
            self.config.db,
            self.uid,
            self.config.api_key,
            model,
            method,
            args,
            kwargs or {},
        )

    def fields_get(self, model: str) -> dict[str, Any]:
        return self.execute_kw(model, "fields_get", [], {"attributes": ["type", "relation", "string"]})

    def search_read(
        self,
        model: str,
        domain: list[Any],
        *,
        fields: list[str],
        limit: int = 20,
        order: str | None = None,
    ) -> list[dict[str, Any]]:
        kwargs: dict[str, Any] = {"fields": fields, "limit": limit}
        if order:
            kwargs["order"] = order
        return self.execute_kw(model, "search_read", [domain], kwargs)

    def read(self, model: str, ids: list[int], *, fields: list[str]) -> list[dict[str, Any]]:
        return self.execute_kw(model, "read", [ids], {"fields": fields})

    def write(self, model: str, ids: list[int], values: dict[str, Any]) -> bool:
        return bool(self.execute_kw(model, "write", [ids, values]))


@dataclass(frozen=True)
class SampleLead:
    id: int
    sample_name: str
    lead_name: str
    receiver: dict[str, Any]
    stage_name: str = ""


class SampleLeadResolver:
    def __init__(self, client: OdooClient) -> None:
        self.client = client
        self._crm_fields: dict[str, Any] | None = None
        self._partner_fields: dict[str, Any] | None = None

    def resolve(self, candidates: list[str]) -> SampleLead:
        errors: list[str] = []
        for candidate in candidates:
            try:
                return self.find_exact(candidate)
            except OdooError as exc:
                errors.append(str(exc))
        joined = "; ".join(errors[-3:]) if errors else "geen kandidaten"
        raise OdooError(f"Geen exacte Odoo CRM match voor kandidaten {candidates}: {joined}")

    def find_exact(self, sample_name: str) -> SampleLead:
        leads = self.find_candidate_leads(sample_name)
        if not leads:
            raise OdooError(f"Geen crm.lead gevonden voor '{sample_name}'.")
        lead = self.choose_single_lead(sample_name, leads)
        partner = self.read_partner(lead)
        request_address = self.read_sample_request_address(int(lead["id"]))
        receiver = self.build_receiver(sample_name, lead, partner, request_address)
        return SampleLead(
            id=int(lead["id"]),
            sample_name=sample_name,
            lead_name=str(lead.get("name") or ""),
            receiver=receiver,
            stage_name=many2one_name(lead.get("stage_id")),
        )

    def read_sample_request_address(self, lead_id: int) -> dict[str, str]:
        try:
            messages = self.client.search_read(
                "mail.message",
                [("model", "=", "crm.lead"), ("res_id", "=", lead_id), ("message_type", "=", "email")],
                fields=["id", "body", "date"],
                limit=5,
                order="date asc",
            )
        except xmlrpc.client.Fault:
            return {}
        for message in messages:
            parsed = parse_sample_request_body(str(message.get("body") or ""))
            if parsed:
                return parsed
        return {}

    def find_candidate_leads(self, sample_name: str) -> list[dict[str, Any]]:
        fields = self.crm_fields
        read_fields = available_fields(
            fields,
            [
                "id",
                "name",
                "contact_name",
                "partner_name",
                "email_from",
                "phone",
                "mobile",
                "street",
                "street2",
                "zip",
                "city",
                "country_id",
                "partner_id",
                "create_date",
                "stage_id",
            ],
        )
        attempts: list[list[Any]] = []
        if "name" in fields:
            attempts.extend(
                [
                    [("name", "=", f"Re: Sample Aanvraag - {sample_name}")],
                    [("name", "=", f"Sample Aanvraag - {sample_name}")],
                    [("name", "=", sample_name)],
                ]
            )
        for field_name in ("contact_name", "partner_name"):
            if field_name in fields:
                attempts.append([(field_name, "=", sample_name)])
        if "partner_id" in fields:
            attempts.append([("partner_id.name", "=", sample_name)])

        found: dict[int, dict[str, Any]] = {}
        for domain in attempts:
            try:
                for lead in self.client.search_read(
                    "crm.lead",
                    domain,
                    fields=read_fields,
                    limit=10,
                    order="create_date desc" if "create_date" in fields else None,
                ):
                    found[int(lead["id"])] = lead
            except xmlrpc.client.Fault:
                continue
        return list(found.values())

    def choose_single_lead(self, sample_name: str, leads: list[dict[str, Any]]) -> dict[str, Any]:
        if len(leads) == 1:
            return leads[0]

        exact_title = f"Re: Sample Aanvraag - {sample_name}".casefold()
        titled = [lead for lead in leads if str(lead.get("name") or "").casefold() == exact_title]
        if len(titled) == 1:
            return titled[0]
        candidates = titled or leads

        open_leads = [lead for lead in candidates if many2one_name(lead.get("stage_id")) not in CLOSED_SAMPLE_STAGES]
        if len(open_leads) == 1:
            return open_leads[0]
        if open_leads:
            return max(open_leads, key=lambda lead: str(lead.get("create_date") or ""))

        descriptions = ", ".join(
            f"{lead.get('id')}:{lead.get('name')}/{many2one_name(lead.get('stage_id'))}" for lead in candidates
        )
        raise OdooError(
            f"Meerdere CRM matches voor '{sample_name}' en geen open lead: {descriptions}"
        )

    def read_partner(self, lead: dict[str, Any]) -> dict[str, Any]:
        partner_value = lead.get("partner_id")
        if not isinstance(partner_value, list) or not partner_value:
            return {}
        partner_id = int(partner_value[0])
        fields = available_fields(
            self.partner_fields,
            [
                "id",
                "name",
                "company_name",
                "commercial_company_name",
                "email",
                "phone",
                "mobile",
                "street",
                "street2",
                "zip",
                "city",
                "country_id",
            ],
        )
        rows = self.client.read("res.partner", [partner_id], fields=fields)
        return rows[0] if rows else {}

    def build_receiver(
        self,
        sample_name: str,
        lead: dict[str, Any],
        partner: dict[str, Any],
        request_address: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        request = request_address or {}
        display_partner_name = many2one_name(lead.get("partner_id"))
        contact_name = first_text(
            request.get("name"),
            sample_name,
            lead.get("contact_name"),
            lead.get("partner_name"),
            partner.get("name"),
            display_partner_name,
        )
        company_name = first_text(
            request.get("company_name"),
            lead.get("partner_name"),
            partner.get("company_name"),
            partner.get("commercial_company_name"),
        )
        if not company_name:
            partner_display = first_text(partner.get("name"), display_partner_name)
            if partner_display and partner_display.casefold() != contact_name.casefold():
                company_name = partner_display
        if company_name.casefold() == contact_name.casefold():
            company_name = ""

        request_street = request.get("street") or ""
        request_house = request.get("house_number") or ""
        request_house_ext = request.get("house_number_ext") or ""
        if request_street and request_house:
            street, house_number, house_number_ext = request_street, request_house, request_house_ext
        else:
            street_value = first_text(lead.get("street"), partner.get("street"))
            street, house_number, house_number_ext = split_street_house(street_value)
            if request_house and not house_number:
                house_number = request_house
                house_number_ext = request_house_ext or house_number_ext

        country_value = request.get("country") or lead.get("country_id") or partner.get("country_id")
        country_code = self.country_code(country_value)
        postcode = first_text(request.get("postcode"), lead.get("zip"), partner.get("zip"))
        city = first_text(request.get("city"), lead.get("city"), partner.get("city"))
        postcode, city = swap_postcode_city_if_inverted(postcode, city)
        return {
            "name": contact_name,
            "company_name": company_name,
            "street": street,
            "house_number": house_number,
            "house_number_ext": house_number_ext,
            "street2": first_text(lead.get("street2"), partner.get("street2")),
            "postcode": postcode,
            "city": city,
            "country": country_code or os.environ.get("ODOO_SAMPLE_DEFAULT_COUNTRY", "NL"),
            "email": first_text(request.get("email"), lead.get("email_from"), partner.get("email")),
            "phone": first_text(
                request.get("phone"),
                lead.get("phone"),
                lead.get("mobile"),
                partner.get("phone"),
                partner.get("mobile"),
            ),
            "odoo_lead_id": lead.get("id"),
            "odoo_lead_name": lead.get("name"),
            "address_source": "sample_request_email" if request_street and request_house else "odoo_partner",
        }

    def country_code(self, country_value: Any) -> str:
        country_id = many2one_id(country_value)
        if not country_id:
            text = first_text(country_value).upper()
            return COUNTRY_NAME_TO_CODE.get(text, text)
        row = self.client.read("res.country", [country_id], fields=["code", "name"])
        if not row:
            return ""
        return first_text(row[0].get("code"), COUNTRY_NAME_TO_CODE.get(first_text(row[0].get("name")).upper()))

    def move_to_stage(self, lead_id: int, stage_name: str) -> dict[str, Any]:
        stage = self.find_crm_stage(stage_name)
        updated = self.client.write("crm.lead", [lead_id], {"stage_id": int(stage["id"])})
        if not updated:
            raise OdooError(f"Odoo gaf geen succesvolle write terug voor CRM lead {lead_id}.")
        return {"ok": True, "stage_id": int(stage["id"]), "stage_name": stage["name"]}

    def find_crm_stage(self, stage_name: str) -> dict[str, Any]:
        stages = self.client.search_read(
            "crm.stage",
            [("name", "=", stage_name)],
            fields=["id", "name"],
            limit=10,
        )
        if not stages:
            raise OdooError(f"CRM stage '{stage_name}' niet gevonden in Odoo.")
        if len(stages) > 1:
            ids = ", ".join(f"{stage.get('id')}:{stage.get('name')}" for stage in stages)
            raise OdooError(f"Meerdere CRM stages met naam '{stage_name}' gevonden: {ids}")
        return stages[0]

    @property
    def crm_fields(self) -> dict[str, Any]:
        if self._crm_fields is None:
            self._crm_fields = self.client.fields_get("crm.lead")
        return self._crm_fields

    @property
    def partner_fields(self) -> dict[str, Any]:
        if self._partner_fields is None:
            self._partner_fields = self.client.fields_get("res.partner")
        return self._partner_fields


CLOSED_SAMPLE_STAGES = {
    "Verzonden/meegegeven",
    "Aftersales mail gestuurd",
    "Geannuleerd",
    "Won",
    "Lost",
}


COUNTRY_NAME_TO_CODE = {
    "NEDERLAND": "NL",
    "NETHERLANDS": "NL",
    "THE NETHERLANDS": "NL",
    "DUITSLAND": "DE",
    "GERMANY": "DE",
    "DEUTSCHLAND": "DE",
    "BELGIE": "BE",
    "BELGIË": "BE",
    "BELGIUM": "BE",
    "FRANCE": "FR",
    "FRANKRIJK": "FR",
}


def config_from_env_or_prompt() -> OdooConfig:
    url = os.environ.get("ODOO_URL") or input("Odoo URL: ").strip()
    db = os.environ.get("ODOO_DB") or input("Odoo database: ").strip()
    user = os.environ.get("ODOO_USER") or input("Odoo gebruiker/e-mail: ").strip()
    api_key = os.environ.get("ODOO_API_KEY") or getpass.getpass("Odoo API key (verborgen): ").strip()
    if not all([url, db, user, api_key]):
        raise SystemExit("Odoo-configuratie ontbreekt (ODOO_URL/ODOO_DB/ODOO_USER/ODOO_API_KEY).")
    return OdooConfig(url=url, db=db, user=user, api_key=api_key)


def available_fields(fields: dict[str, Any], requested: list[str]) -> list[str]:
    return [field for field in requested if field == "id" or field in fields]


def first_text(*values: Any) -> str:
    for value in values:
        if value is False or value is None:
            continue
        if isinstance(value, list):
            if len(value) >= 2 and str(value[1]).strip():
                return str(value[1]).strip()
            if value and str(value[0]).strip():
                return str(value[0]).strip()
        elif value is not None and str(value).strip():
            return str(value).strip()
    return ""


def many2one_id(value: Any) -> int:
    if isinstance(value, list) and value:
        try:
            return int(value[0])
        except (TypeError, ValueError):
            return 0
    return 0


def many2one_name(value: Any) -> str:
    if isinstance(value, list) and len(value) >= 2:
        return str(value[1]).strip()
    return ""


SAMPLE_REQUEST_FIELD_ALIASES: dict[str, tuple[str, ...]] = {
    "company_name": ("Bedrijf",),
    "street": ("Straat",),
    "house_number": ("Huisnummer", "Huisnr"),
    "house_number_ext": ("Toevoeging",),
    "postcode": ("Postcode",),
    "city": ("Plaats", "Woonplaats", "Stad"),
    "country": ("Land",),
    "email": ("E-mail", "Email"),
    "phone": ("Telefoon", "Telefoonnummer"),
}

SAMPLE_REQUEST_VALUE_STOP_RE = re.compile(
    r"\s+(?:\(Verplicht\)|\(Optioneel\)|Benodigd\s+aantal|Opmerking|You\s+can\s+edit|Naam|Sample\s+\d)",
    re.IGNORECASE,
)


def parse_sample_request_body(html_body: str) -> dict[str, str]:
    if not html_body:
        return {}
    text = re.sub(r"<[^>]+>", " ", html_body)
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return {}
    label_pattern = "|".join(
        re.escape(alias) for aliases in SAMPLE_REQUEST_FIELD_ALIASES.values() for alias in aliases
    )
    if not label_pattern:
        return {}
    splitter = re.compile(rf"({label_pattern})\s*:\s*", re.IGNORECASE)
    parts = splitter.split(text)
    if len(parts) < 3:
        return {}

    result: dict[str, str] = {}
    for index in range(1, len(parts), 2):
        raw_label = parts[index].strip()
        raw_value = parts[index + 1] if index + 1 < len(parts) else ""
        key = match_request_field_key(raw_label)
        if not key or key in result:
            continue
        value = SAMPLE_REQUEST_VALUE_STOP_RE.split(raw_value, maxsplit=1)[0].strip().strip(",;")
        if not value:
            continue
        result[key] = value

    house = result.get("house_number", "")
    match = re.match(r"^(\d+)\s*([A-Za-z0-9\-]*)$", house)
    if match:
        result["house_number"] = match.group(1)
        if match.group(2):
            result["house_number_ext"] = match.group(2)
    return result


def match_request_field_key(label: str) -> str | None:
    normalized = label.casefold()
    for key, aliases in SAMPLE_REQUEST_FIELD_ALIASES.items():
        if any(normalized == alias.casefold() for alias in aliases):
            return key
    return None


NL_POSTCODE_RE = re.compile(r"^\s*[1-9]\d{3}\s?[A-Za-z]{2}\s*$")


def swap_postcode_city_if_inverted(postcode: str, city: str) -> tuple[str, str]:
    if not postcode and not city:
        return postcode, city
    if NL_POSTCODE_RE.match(postcode or ""):
        return postcode, city
    if NL_POSTCODE_RE.match(city or ""):
        return city, postcode
    return postcode, city


def split_street_house(value: str) -> tuple[str, str, str]:
    text = first_text(value)
    if not text:
        return "", "", ""
    match = re_match_street_house(text)
    if not match:
        return text, "", ""
    return (
        match.group("street").strip(" ,"),
        match.group("number").replace(" ", ""),
        (match.group("ext") or "").strip(" -"),
    )


def re_match_street_house(text: str) -> re.Match[str] | None:
    return re.match(
        r"^(?P<street>.*?)[\s,]+(?P<number>\d+\s*[A-Za-z]?)(?:[\s/-]+(?P<ext>[A-Za-z0-9]+))?$",
        text.strip(),
    )
