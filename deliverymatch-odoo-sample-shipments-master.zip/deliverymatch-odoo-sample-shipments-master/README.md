# DeliveryMatch sample shipments uit Odoo CRM

Tooling om een PNG/JPG met sample-aanvragen te OCR'en, per naam exact de CRM-aanvraag in Odoo te zoeken, en daaruit een DeliveryMatch sample shipment te maken.

De oude WH/OUT sandboxcommando's staan er nog in, maar de primaire flow is nu:

1. OCR leest regels zoals `Re: Sample Aanvraag - Iris Siemerink`.
2. De tool zoekt exact in `crm.lead` op:
   - `Re: Sample Aanvraag - <naam>`;
   - `Sample Aanvraag - <naam>`;
   - `<naam>`;
   - `contact_name`, `partner_name` of `partner_id.name`.
3. Odoo levert naam, adres, e-mail en telefoon.
4. DeliveryMatch krijgt een sample shipment met `reference = sample`.
5. Echt schrijven gebeurt alleen met `--execute-write`.

## Configuratie

Maak lokaal een `.env` op basis van `.env.example` of zet de variabelen in PowerShell:

```powershell
cd "C:\chatgpt codex\deliverymatch-odoo-test"
$env:PYTHONPATH = "$PWD\src"

$env:ODOO_URL = "https://tegelfabriek-aardig-tegelfabriek.odoo.com"
$env:ODOO_DB = "..."
$env:ODOO_USER = "..."
$env:ODOO_API_KEY = "..."

$env:DELIVERYMATCH_CLIENT_ID = "101276"
$env:DELIVERYMATCH_ENV = "prod"
```

Zet geen echte API keys in git.

## GitHub Actions dry-run zonder PowerShell

De repo heeft een handmatige workflow: **Actions -> Sample shipment -> Run workflow**.

Zet eerst deze repository secrets in GitHub:

- `ODOO_DB`
- `ODOO_USER`
- `ODOO_API_KEY`
- optioneel `ODOO_URL` als die afwijkt van `https://tegelfabriek-aardig-tegelfabriek.odoo.com`
- optioneel `DELIVERYMATCH_CLIENT_ID`, anders gebruikt de tool `101276`
- optioneel voor dry-run duplicate-check en verplicht voor echte writes: `DELIVERYMATCH_API_KEY`

Voor een dry-run van alle namen laat je `only` leeg en geef je input via `sample_text`, `image_paths` of `image_urls`.

Voor alleen Iris vul je:

- `only`: `Iris Siemerink`
- `sample_text`: `Re: Sample Aanvraag - Iris Siemerink`
- `execute_write`: uit

De workflow zoekt de naam/namen in Odoo en schrijft geen DeliveryMatch shipment zolang `execute_write` uit staat. Na afloop download je onder de workflow-run het artifact `sample-shipment-output`; daarin staat `sample_shipments_run.json` met de payloads.

Voor alle 43 zonder foto-OCR kun je `sample_text` vullen met regels zoals:

```text
Re: Sample Aanvraag - Iris Siemerink
Re: Sample Aanvraag - Lotte Spek
Re: Sample Aanvraag - Inge Beer
```

Laat `only` dan leeg.

Wil je later afbeeldingen vanuit GitHub gebruiken, dan kan dat op twee manieren:

- upload afbeeldingen in de private repo en vul `image_paths` met bijvoorbeeld `inputs/foto1.png,inputs/foto2.png,inputs/foto3.png`;
- of vul `image_urls` met directe image-URLs.

Laat `execute_write` uit voor dry-runs. Zet `execute_write` alleen aan als de payload goed is gecontroleerd.

Bij `execute_write=true` staat `update_odoo_stage` standaard aan. Na een succesvolle shipment of een bestaande DeliveryMatch duplicate zet de tool de Odoo CRM lead naar `processed_stage_name`, standaard `Verzonden/meegegeven`.

De tool leest het sample-adres bij voorkeur uit de oorspronkelijke aanvraag-email (chatter `mail.message`) van de Odoo CRM lead. Labels `Straat:`, `Huisnummer:`, `Postcode:`, `Plaats:`, `Land:` worden uit de body gehaald. Dit dekt situaties waarbij Odoo zelf alleen een straatnaam zonder huisnummer heeft opgeslagen. Lukt het niet, valt hij terug op `street`/`zip`/`city` van de lead/partner.

De flow heeft drie safeguards:

- als `DELIVERYMATCH_API_KEY` beschikbaar is, zoekt de tool read-only in DeliveryMatch op het stabiele `orderNumber` (`SAMPLE-<odoo_lead_id>`); als die al bestaat, krijgt de regel status `skipped_duplicate` en wordt er niets aangemaakt;
- als Odoo de CRM naam wel vindt maar adresvelden ontbreken, krijgt de regel status `error` met de ontbrekende velden/adresfout en wordt er niets naar DeliveryMatch gestuurd.
- de Odoo fase wordt alleen aangepast bij `execute_write=true` en pas nadat de shipment succesvol is verwerkt of als bestaande duplicate is vastgesteld.

Bij `execute_write=true` verwerkt de tool alleen Odoo CRM leads waarvan de stage `Te versturen/binnen` is. Leads in andere stages (bijvoorbeeld `Verzonden/meegegeven` of `Aftersales mail gestuurd`) worden overgeslagen met status `skipped_stage`. Override de verplichte stage via env `SAMPLE_REQUIRED_STAGE`.

Met workflow-input `force` (of CLI `--force`) sla je de DeliveryMatch duplicate-check én de lokale duplicate-log over. De stage-check blijft actief: alleen leads in `Te versturen/binnen` worden ook bij `--force` verwerkt. Het `orderNumber` blijft altijd `SAMPLE-<odoo_lead_id>`.

Workflow-input `bypass_all_checks` (CLI `--bypass-all-checks`) negeert álles: stage-check én duplicate-checks. De tool maakt een shipment aan zodra een Odoo CRM lead gevonden is. Als DeliveryMatch een 409 `already exists` geeft, retrye'd de tool eenmalig met `SAMPLE-<lead_id>-RETRY-YYYYMMDD-HHMMSS` zodat de shipment alsnog wordt aangemaakt naast de bestaande.

De default `client.action` voor sample shipments is `book` (DHL Parcel + service level `product[DFY]options[DOOR]` worden direct vastgezet en er ontstaat een carrier order ID). Override via `SAMPLE_SHIPMENT_ACTION=save` als je alleen een draft wilt.

## Lokaal: namen uit een PNG lezen

```powershell
$env:PYTHONPATH = "$PWD\src"
python -m dm_odoo_test.cli extract-samples --image .\inputs\foto1.png --image .\inputs\foto2.png --image .\inputs\foto3.png
```

De OCR gebruikt op Windows standaard Windows OCR (`nl-NL`) en probeert automatisch 0/90/180/270 graden rotaties. Als OCR niet beschikbaar is, kun je eerst tekst opslaan en die meegeven:

```powershell
python -m dm_odoo_test.cli extract-samples --ocr-text .\inputs\samplelijst_ocr.txt
```

## Dry-run payloads bouwen

Dry-run zoekt wel in Odoo, maar schrijft niets naar DeliveryMatch:

```powershell
python -m dm_odoo_test.cli create-sample-shipments `
  --image .\inputs\foto1.png `
  --image .\inputs\foto2.png `
  --image .\inputs\foto3.png `
  --only "Iris Siemerink" `
  --print-payloads `
  --out outputs\iris_sample_dry_run.json
```

## Eerste live test: alleen Iris

Kopieer eerst de DeliveryMatch API key naar je clipboard. Daarna:

```powershell
.\scripts\run_sample_shipments.ps1 `
  -Image .\inputs\foto1.png,.\inputs\foto2.png,.\inputs\foto3.png `
  -Only "Iris Siemerink" `
  -ClientId 101276 `
  -Env prod `
  -ExecuteWrite
```

De tool schrijft een runrapport naar `outputs/sample_shipments_run.json` en bewaart succesvolle live inserts in `outputs/sample_shipments_log.json`. Een tweede run voor dezelfde Odoo CRM lead wordt lokaal overgeslagen, tenzij je bewust `--force` gebruikt.

## DeliveryMatch defaults

De sample shipment gebruikt defaults uit de DeliveryMatch screenshot:

- sender: Tegelfabriek-Nederland, Vonderweg 25, 7468DC Enter, NL;
- carrier: `DHLPARCEL`;
- service level: `product[DFY]options[DOOR]`;
- `reference`: `sample`;
- 1 colli;
- package/product description: `Goods` / `Sample`;
- gewicht: `10 kg`;
- afmetingen: `1 x 1 x 1 cm`;
- waarde: `0 EUR`.

Deze defaults zijn overschrijfbaar met omgevingsvariabelen zoals `SAMPLE_SHIPMENT_WEIGHT_KG`, `SAMPLE_SHIPMENT_SERVICE_LEVEL`, `SAMPLE_SENDER_EMAIL`, enzovoort. Zie `.env.example`.

## Tests

```powershell
$env:PYTHONPATH = "$PWD\src"
python -m unittest discover -s tests -v
```

## Legacy WH/OUT sandbox

De oude testflow voor een Odoo levering naar `/insertShipment` is behouden:

```powershell
python -m dm_odoo_test.cli build-payload --client-id 101276 --out outputs\ord18026_insert_payload.json
python -m dm_odoo_test.cli validate-payload --payload outputs\ord18026_insert_payload.json
.\scripts\run_deliverymatch_test.ps1 -Command insert-shipment -ClientId 101276 -Env prod -Payload outputs\ord18026_insert_payload.json -ExecuteWrite
```
